#!/usr/bin/env python3
"""
Reusable Excel Spreadsheets Template
====================================
Copy this file and adapt the CONFIG section for your own spreadsheet task.
It demonstrates the core helpers from the Excel Spreadsheets Toolkit
(Chapter 13 of Automate the Boring Stuff – extended).

Typical workflow
----------------
1. Load (or create) a workbook
2. Select / create a sheet
3. Read or write cells / ranges
4. Apply styles, formulas, freeze panes, charts as needed
5. Save to a new file
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make the toolkit importable when this template lives in templates/
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from excel_spreadsheets import (
    load_workbook_safe,
    get_sheet,
    create_workbook,
    write_cells,
    style_header_row,
    auto_column_width,
    freeze_header,
    set_formula,
    add_bar_chart,
    save_workbook,
    Reference,  # re-exported via openpyxl in the toolkit if needed
)

# ---------------------------------------------------------------------------
# CONFIG – edit these values for your task
# ---------------------------------------------------------------------------
INPUT_FILE = Path("data/example.xlsx")          # existing workbook (or None)
OUTPUT_FILE = Path("reports/my_output.xlsx")
SHEET_NAME = "Sheet1"                           # or None for active
HEADER_ROW = 1

# Example: simple transformation – read produce-like data and add a TOTAL col
# ---------------------------------------------------------------------------

def main() -> None:
    if INPUT_FILE and INPUT_FILE.exists():
        wb = load_workbook_safe(INPUT_FILE)
        ws = get_sheet(wb, SHEET_NAME)
        print(f"Loaded {INPUT_FILE.name} – sheet '{ws.title}' "
              f"({ws.max_row} rows × {ws.max_column} cols)")
    else:
        # Create a brand-new workbook from scratch
        wb = create_workbook("My Data")
        ws = wb.active
        write_cells(ws, [
            ["Item", "Qty", "Unit Price", "Total"],
            ["Widget", 10, 2.5, None],
            ["Gadget", 5, 12.0, None],
            ["Doohickey", 3, 7.25, None],
        ])
        # Add formulas for the Total column
        for row in range(2, 5):
            set_formula(ws, f"D{row}", f"=B{row}*C{row}")
        style_header_row(ws, 1)
        freeze_header(ws)
        auto_column_width(ws)
        print("Created new workbook from scratch")

    # Optional: add a chart if numeric data is present
    # data_ref = Reference(ws, min_col=2, min_row=1, max_col=2, max_row=ws.max_row)
    # add_bar_chart(ws, data_ref, title="Quantities", anchor="F2")

    save_workbook(wb, OUTPUT_FILE)
    print(f"Saved → {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
