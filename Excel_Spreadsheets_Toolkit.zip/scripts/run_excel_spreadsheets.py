#!/usr/bin/env python3
"""
CLI runner for the Extended Excel Spreadsheets Toolkit.
Simply forwards all arguments to excel_spreadsheets.main().

Examples
--------
    python run_excel_spreadsheets.py demo
    python run_excel_spreadsheets.py census
    python run_excel_spreadsheets.py update-produce
    python run_excel_spreadsheets.py multitable 6
    python run_excel_spreadsheets.py blank-rows 3 2 --input data/example.xlsx
    python run_excel_spreadsheets.py invert --input data/example.xlsx
    python run_excel_spreadsheets.py text2sheet data/fruits.txt data/veggies.txt
    python run_excel_spreadsheets.py sheet2text --input data/example.xlsx
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the scripts directory is on the path when run from project root
sys.path.insert(0, str(Path(__file__).resolve().parent))

from excel_spreadsheets import main

if __name__ == "__main__":
    sys.exit(main())
