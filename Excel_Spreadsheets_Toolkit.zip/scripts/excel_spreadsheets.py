#!/usr/bin/env python3
"""
Extended Working with Excel Spreadsheets Toolkit
================================================
Extends Chapter 13 of "Automate the Boring Stuff with Python" (2nd Edition)
by Al Sweigart – Working with Excel Spreadsheets – with production-ready
helpers, modern openpyxl (3.x) practices, robust error handling, logging,
CLI support, reusable pipelines, and complete implementations of the
practice projects.

Modules & techniques covered + enhancements
-------------------------------------------
1. Reading workbooks      – load_workbook, sheetnames, active, cell access,
                            max_row / max_column, column letter ↔ index utils
2. Writing workbooks      – Workbook(), create/delete sheets, write values,
                            save with safety copy
3. Styles & formatting    – Font, PatternFill, Alignment, Border, NamedStyle
4. Formulas               – write Excel formulas, data_only mode for values
5. Dimensions & layout    – row height, column width, merge/unmerge, freeze panes
6. Charts                 – Bar, Line, Pie, Scatter with Reference / Series
7. Project: Census reader – aggregate population & tract counts by county
8. Project: Produce updater – bulk price correction from a dict of updates
9. Practice projects      – Multiplication Table, Blank Row Inserter,
                            Cell Inverter, Text→Spreadsheet, Spreadsheet→Text

Usage (library)
---------------
    from excel_spreadsheets import (
        load_workbook_safe, get_sheet, read_range, write_cells,
        create_styled_workbook, apply_font, set_formula,
        freeze_header, add_bar_chart, read_census_data,
        update_produce_prices, make_multiplication_table,
        insert_blank_rows, invert_cells, text_files_to_spreadsheet,
        spreadsheet_to_text_files
    )

Usage (CLI – see run_excel_spreadsheets.py)
------------------------------------------
    python run_excel_spreadsheets.py demo
    python run_excel_spreadsheets.py census --input data/censuspopdata_synth.xlsx
    python run_excel_spreadsheets.py update-produce --input data/produceSales_synth.xlsx
    python run_excel_spreadsheets.py multitable 8
    python run_excel_spreadsheets.py invert --input data/example.xlsx
"""

from __future__ import annotations

import argparse
import logging
import os
import pprint
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple, Union

# ---------------------------------------------------------------------------
# Third-party
# ---------------------------------------------------------------------------
try:
    import openpyxl
    from openpyxl import Workbook, load_workbook
    from openpyxl.styles import (
        Alignment,
        Border,
        Font,
        NamedStyle,
        PatternFill,
        Side,
    )
    from openpyxl.utils import column_index_from_string, get_column_letter
    from openpyxl.chart import (
        BarChart,
        LineChart,
        PieChart,
        Reference,
        Series,
    )
    from openpyxl.chart.label import DataLabelList
    from openpyxl.worksheet.worksheet import Worksheet
except ImportError as e:  # pragma: no cover
    print("ERROR: openpyxl is required. Install with:  pip install openpyxl")
    raise SystemExit(1) from e

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("excel_spreadsheets")

# ---------------------------------------------------------------------------
# Path helpers (project-root aware)
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
REPORTS = ROOT / "reports"
FIGURES = REPORTS / "figures" / "excel_spreadsheets"


def ensure_dirs() -> None:
    """Create standard output directories if they do not exist."""
    for d in (DATA, REPORTS, FIGURES):
        d.mkdir(parents=True, exist_ok=True)


# ===========================================================================
# 1. Reading helpers
# ===========================================================================

def load_workbook_safe(
    path: Union[str, Path],
    data_only: bool = False,
    read_only: bool = False,
) -> openpyxl.Workbook:
    """
    Load an Excel workbook with clear error messages.

    Parameters
    ----------
    path : str | Path
        Path to the .xlsx file.
    data_only : bool
        If True, formula cells return computed values (requires prior Excel save).
    read_only : bool
        Memory-efficient mode for very large files (write operations disabled).

    Returns
    -------
    openpyxl.Workbook
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Workbook not found: {path}")
    log.info("Loading workbook: %s (data_only=%s)", path.name, data_only)
    return load_workbook(path, data_only=data_only, read_only=read_only)


def get_sheet(
    wb: openpyxl.Workbook,
    name: Optional[str] = None,
) -> Worksheet:
    """
    Return a worksheet by name, or the active sheet if name is None.
    """
    if name is None:
        return wb.active
    if name not in wb.sheetnames:
        raise KeyError(
            f"Sheet '{name}' not found. Available: {wb.sheetnames}"
        )
    return wb[name]


def cell_value(sheet: Worksheet, coord: str) -> Any:
    """Convenience: sheet['A1'].value"""
    return sheet[coord].value


def read_range(
    sheet: Worksheet,
    start: str,
    end: str,
) -> List[List[Any]]:
    """
    Read a rectangular range into a list-of-lists (rows of values).

    Example
    -------
    >>> data = read_range(sheet, "A1", "C7")
    """
    rows = []
    for row in sheet[start:end]:
        rows.append([cell.value for cell in row])
    return rows


def iter_rows_values(
    sheet: Worksheet,
    min_row: int = 1,
    max_row: Optional[int] = None,
    min_col: int = 1,
    max_col: Optional[int] = None,
    values_only: bool = True,
) -> Iterable:
    """Thin wrapper around sheet.iter_rows with sensible defaults."""
    return sheet.iter_rows(
        min_row=min_row,
        max_row=max_row or sheet.max_row,
        min_col=min_col,
        max_col=max_col or sheet.max_column,
        values_only=values_only,
    )


def column_letter_to_index(letter: str) -> int:
    """'A' → 1, 'AA' → 27, etc."""
    return column_index_from_string(letter)


def index_to_column_letter(idx: int) -> str:
    """1 → 'A', 27 → 'AA', etc."""
    return get_column_letter(idx)


# ===========================================================================
# 2. Writing helpers
# ===========================================================================

def create_workbook(title: str = "Sheet") -> openpyxl.Workbook:
    """Create a fresh workbook and rename the default sheet."""
    wb = Workbook()
    wb.active.title = title
    return wb


def write_cells(
    sheet: Worksheet,
    data: Sequence[Sequence[Any]],
    start_row: int = 1,
    start_col: int = 1,
) -> None:
    """
    Write a 2-D sequence into the sheet starting at (start_row, start_col).
    """
    for r_offset, row in enumerate(data):
        for c_offset, value in enumerate(row):
            sheet.cell(
                row=start_row + r_offset,
                column=start_col + c_offset,
                value=value,
            )


def save_workbook(
    wb: openpyxl.Workbook,
    path: Union[str, Path],
    overwrite: bool = True,
) -> Path:
    """
    Save workbook, optionally refusing to overwrite an existing file.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not overwrite:
        raise FileExistsError(f"Refusing to overwrite: {path}")
    wb.save(path)
    log.info("Saved workbook → %s", path)
    return path


def add_sheet(
    wb: openpyxl.Workbook,
    title: str,
    index: Optional[int] = None,
) -> Worksheet:
    """Create and return a new sheet (optionally at a given position)."""
    if index is None:
        return wb.create_sheet(title)
    return wb.create_sheet(title, index)


def remove_sheet(wb: openpyxl.Workbook, title: str) -> None:
    """Delete a sheet by name."""
    if title in wb.sheetnames:
        del wb[title]
        log.info("Removed sheet '%s'", title)


# ===========================================================================
# 3. Styles & formatting
# ===========================================================================

DEFAULT_HEADER_FILL = PatternFill("solid", fgColor="2F5496")
DEFAULT_HEADER_FONT = Font(bold=True, color="FFFFFF", name="Calibri", size=11)
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)


def apply_font(
    cell,
    name: str = "Calibri",
    size: int = 11,
    bold: bool = False,
    italic: bool = False,
    color: Optional[str] = None,
) -> None:
    """Apply a Font to a single cell."""
    kwargs: Dict[str, Any] = {"name": name, "size": size, "bold": bold, "italic": italic}
    if color:
        kwargs["color"] = color
    cell.font = Font(**kwargs)


def style_header_row(
    sheet: Worksheet,
    row: int = 1,
    fill: PatternFill = DEFAULT_HEADER_FILL,
    font: Font = DEFAULT_HEADER_FONT,
) -> None:
    """Style every non-empty cell in a header row."""
    for cell in sheet[row]:
        if cell.value is not None:
            cell.fill = fill
            cell.font = font
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = THIN_BORDER


def auto_column_width(
    sheet: Worksheet,
    min_width: int = 8,
    max_width: int = 40,
    padding: int = 2,
) -> None:
    """
    Rough auto-size of columns based on string length of cell values.
    """
    for col_cells in sheet.columns:
        col_letter = get_column_letter(col_cells[0].column)
        lengths = []
        for cell in col_cells:
            if cell.value is not None:
                lengths.append(len(str(cell.value)))
        if lengths:
            width = min(max(max(lengths) + padding, min_width), max_width)
            sheet.column_dimensions[col_letter].width = width


# ===========================================================================
# 4. Formulas
# ===========================================================================

def set_formula(sheet: Worksheet, coord: str, formula: str) -> None:
    """
    Write an Excel formula (must start with '=').
    Example: set_formula(sheet, "D2", "=ROUND(B2*C2, 2)")
    """
    if not formula.startswith("="):
        formula = "=" + formula
    sheet[coord] = formula


# ===========================================================================
# 5. Dimensions, merge, freeze
# ===========================================================================

def set_row_height(sheet: Worksheet, row: int, height: float) -> None:
    """Height in points (1 point ≈ 1/72 inch). Default ≈ 15."""
    sheet.row_dimensions[row].height = height


def set_column_width(sheet: Worksheet, col: Union[str, int], width: float) -> None:
    """Width in approximate character units. Default ≈ 8.43."""
    letter = col if isinstance(col, str) else get_column_letter(col)
    sheet.column_dimensions[letter].width = width


def merge_cells(sheet: Worksheet, range_str: str) -> None:
    """Merge a rectangular range, e.g. 'A1:D3'."""
    sheet.merge_cells(range_str)


def unmerge_cells(sheet: Worksheet, range_str: str) -> None:
    sheet.unmerge_cells(range_str)


def freeze_header(sheet: Worksheet, cell: str = "A2") -> None:
    """
    Freeze panes so that all rows above and columns left of `cell` stay visible.
    Common choice: 'A2' freezes the first row.
    """
    sheet.freeze_panes = cell


# ===========================================================================
# 6. Charts
# ===========================================================================

def add_bar_chart(
    sheet: Worksheet,
    data_ref: Reference,
    cats_ref: Optional[Reference] = None,
    title: str = "Chart",
    anchor: str = "E2",
    style: int = 10,
) -> BarChart:
    """
    Create a simple bar chart and place it on the sheet.
    """
    chart = BarChart()
    chart.type = "col"
    chart.style = style
    chart.title = title
    chart.y_axis.title = "Value"
    chart.x_axis.title = "Category"
    chart.add_data(data_ref, titles_from_data=False)
    if cats_ref is not None:
        chart.set_categories(cats_ref)
    sheet.add_chart(chart, anchor)
    return chart


def add_line_chart(
    sheet: Worksheet,
    data_ref: Reference,
    cats_ref: Optional[Reference] = None,
    title: str = "Line Chart",
    anchor: str = "E2",
) -> LineChart:
    chart = LineChart()
    chart.title = title
    chart.style = 10
    chart.y_axis.title = "Value"
    chart.x_axis.title = "Category"
    chart.add_data(data_ref, titles_from_data=False)
    if cats_ref is not None:
        chart.set_categories(cats_ref)
    sheet.add_chart(chart, anchor)
    return chart


def add_pie_chart(
    sheet: Worksheet,
    data_ref: Reference,
    cats_ref: Optional[Reference] = None,
    title: str = "Pie Chart",
    anchor: str = "E2",
) -> PieChart:
    chart = PieChart()
    chart.title = title
    chart.add_data(data_ref, titles_from_data=False)
    if cats_ref is not None:
        chart.set_categories(cats_ref)
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showPercent = True
    chart.dataLabels.showVal = False
    chart.dataLabels.showCatName = False
    sheet.add_chart(chart, anchor)
    return chart


# ===========================================================================
# 7. Project – Reading Data from a Spreadsheet (Census)
# ===========================================================================

def read_census_data(
    path: Union[str, Path],
    sheet_name: str = "Population by Census Tract",
    state_col: str = "B",
    county_col: str = "C",
    pop_col: str = "D",
    start_row: int = 2,
) -> Dict[str, Dict[str, Dict[str, int]]]:
    """
    Aggregate census-tract rows into:

        {state: {county: {"tracts": N, "pop": total_pop}}}

    Matches the structure of the classic Automate the Boring Stuff project.
    """
    wb = load_workbook_safe(path)
    sheet = get_sheet(wb, sheet_name)

    county_data: Dict[str, Dict[str, Dict[str, int]]] = {}
    log.info("Reading census rows from %s …", Path(path).name)

    for row in range(start_row, sheet.max_row + 1):
        state = sheet[f"{state_col}{row}"].value
        county = sheet[f"{county_col}{row}"].value
        pop = sheet[f"{pop_col}{row}"].value
        if state is None or county is None:
            continue
        county_data.setdefault(state, {})
        county_data[state].setdefault(county, {"tracts": 0, "pop": 0})
        county_data[state][county]["tracts"] += 1
        try:
            county_data[state][county]["pop"] += int(pop or 0)
        except (TypeError, ValueError):
            log.warning("Non-integer population at row %s: %r", row, pop)

    return county_data


def write_census_py(
    county_data: Dict,
    out_path: Union[str, Path] = "census2010.py",
) -> Path:
    """Write the aggregated dictionary as a Python module (pprint style)."""
    out_path = Path(out_path)
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("# Auto-generated by excel_spreadsheets.read_census_data\n")
        f.write("allData = " + pprint.pformat(county_data))
    log.info("Wrote Python data module → %s", out_path)
    return out_path


def census_summary_table(
    county_data: Dict,
    out_xlsx: Union[str, Path],
) -> Path:
    """
    Also produce a neat summary spreadsheet (state / county / tracts / pop).
    """
    wb = create_workbook("County Summary")
    ws = wb.active
    write_cells(ws, [["State", "County", "Tracts", "Population"]], start_row=1)
    style_header_row(ws, 1)

    row = 2
    for state in sorted(county_data):
        for county in sorted(county_data[state]):
            d = county_data[state][county]
            write_cells(
                ws,
                [[state, county, d["tracts"], d["pop"]]],
                start_row=row,
            )
            row += 1

    auto_column_width(ws)
    freeze_header(ws)
    return save_workbook(wb, out_xlsx)


# ===========================================================================
# 8. Project – Updating a Spreadsheet (Produce prices)
# ===========================================================================

DEFAULT_PRICE_UPDATES = {
    "Garlic": 3.07,
    "Celery": 1.19,
    "Lemon": 1.27,
}


def update_produce_prices(
    path: Union[str, Path],
    price_updates: Optional[Dict[str, float]] = None,
    produce_col: int = 1,
    price_col: int = 2,
    start_row: int = 2,
    out_path: Optional[Union[str, Path]] = None,
) -> Path:
    """
    Walk every data row; if the produce name is a key in price_updates,
    overwrite the unit price. Save to a new file by default.
    """
    price_updates = price_updates or DEFAULT_PRICE_UPDATES
    wb = load_workbook_safe(path)
    sheet = wb.active  # assume first/only sheet

    changed = 0
    for row in range(start_row, sheet.max_row + 1):
        name = sheet.cell(row=row, column=produce_col).value
        if name in price_updates:
            old = sheet.cell(row=row, column=price_col).value
            new = price_updates[name]
            if old != new:
                sheet.cell(row=row, column=price_col).value = new
                changed += 1

    if out_path is None:
        p = Path(path)
        out_path = p.with_name(p.stem + "_updated" + p.suffix)
    out_path = Path(out_path)
    save_workbook(wb, out_path)
    log.info("Updated %d price cells → %s", changed, out_path)
    return out_path


# ===========================================================================
# 9. Practice Projects
# ===========================================================================

def make_multiplication_table(
    n: int,
    out_path: Union[str, Path] = "multiplication_table.xlsx",
) -> Path:
    """
    Create an N×N multiplication table.
    Row 1 and column A contain labels and are bold.
    """
    if n < 1 or n > 50:
        raise ValueError("n should be between 1 and 50")
    wb = create_workbook("Multiplication")
    ws = wb.active

    # Labels
    for i in range(1, n + 1):
        cell_r = ws.cell(row=1, column=i + 1, value=i)
        cell_c = ws.cell(row=i + 1, column=1, value=i)
        cell_r.font = Font(bold=True)
        cell_c.font = Font(bold=True)
        cell_r.fill = PatternFill("solid", fgColor="D9E2F3")
        cell_c.fill = PatternFill("solid", fgColor="D9E2F3")

    # Products
    for r in range(1, n + 1):
        for c in range(1, n + 1):
            ws.cell(row=r + 1, column=c + 1, value=r * c)

    # Cosmetic
    for col in range(1, n + 2):
        ws.column_dimensions[get_column_letter(col)].width = 5
    freeze_header(ws, "B2")
    return save_workbook(wb, out_path)


def insert_blank_rows(
    path: Union[str, Path],
    n: int,
    m: int,
    out_path: Optional[Union[str, Path]] = None,
) -> Path:
    """
    Starting at row N, insert M blank rows.
    Implementation: read everything, then write with an offset after N.
    """
    wb = load_workbook_safe(path)
    sheet = wb.active
    max_r, max_c = sheet.max_row, sheet.max_column

    # Snapshot all values
    data = []
    for r in range(1, max_r + 1):
        data.append([sheet.cell(row=r, column=c).value for c in range(1, max_c + 1)])

    # Build new workbook
    new_wb = create_workbook(sheet.title)
    new_ws = new_wb.active

    # Copy rows 1 .. N-1 unchanged
    for r_idx, row in enumerate(data[: n - 1], start=1):
        for c_idx, val in enumerate(row, start=1):
            new_ws.cell(row=r_idx, column=c_idx, value=val)

    # Skip M blank rows, then copy the rest
    dest_row = n + m
    for row in data[n - 1 :]:
        for c_idx, val in enumerate(row, start=1):
            new_ws.cell(row=dest_row, column=c_idx, value=val)
        dest_row += 1

    if out_path is None:
        p = Path(path)
        out_path = p.with_name(p.stem + f"_blank_{n}_{m}" + p.suffix)
    return save_workbook(new_wb, out_path)


def invert_cells(
    path: Union[str, Path],
    out_path: Optional[Union[str, Path]] = None,
) -> Path:
    """
    Transpose the sheet: value at (row r, col c) moves to (row c, col r).
    """
    wb = load_workbook_safe(path)
    sheet = wb.active
    max_r, max_c = sheet.max_row, sheet.max_column

    # Read into matrix
    matrix = [
        [sheet.cell(row=r, column=c).value for c in range(1, max_c + 1)]
        for r in range(1, max_r + 1)
    ]

    new_wb = create_workbook(sheet.title + " (inverted)")
    new_ws = new_wb.active

    # Write transposed
    for r, row in enumerate(matrix):
        for c, val in enumerate(row):
            new_ws.cell(row=c + 1, column=r + 1, value=val)

    auto_column_width(new_ws)
    if out_path is None:
        p = Path(path)
        out_path = p.with_name(p.stem + "_inverted" + p.suffix)
    return save_workbook(new_wb, out_path)


def text_files_to_spreadsheet(
    text_paths: Sequence[Union[str, Path]],
    out_path: Union[str, Path] = "from_text_files.xlsx",
) -> Path:
    """
    Each text file becomes a column; each line becomes a successive row.
    """
    wb = create_workbook("From Text")
    ws = wb.active

    for col_idx, tpath in enumerate(text_paths, start=1):
        tpath = Path(tpath)
        if not tpath.exists():
            log.warning("Skipping missing file: %s", tpath)
            continue
        lines = tpath.read_text(encoding="utf-8").splitlines()
        # Header = filename
        ws.cell(row=1, column=col_idx, value=tpath.name)
        apply_font(ws.cell(row=1, column=col_idx), bold=True)
        for row_idx, line in enumerate(lines, start=2):
            ws.cell(row=row_idx, column=col_idx, value=line)

    style_header_row(ws, 1)
    auto_column_width(ws)
    freeze_header(ws)
    return save_workbook(wb, out_path)


def spreadsheet_to_text_files(
    path: Union[str, Path],
    out_dir: Union[str, Path] = "text_columns",
) -> List[Path]:
    """
    Reverse of the previous: each column is written to its own .txt file.
    """
    wb = load_workbook_safe(path)
    sheet = wb.active
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    written = []
    for col in range(1, sheet.max_column + 1):
        letter = get_column_letter(col)
        # Use header if present, else ColumnX
        header = sheet.cell(row=1, column=col).value
        fname = f"{header or f'Column{letter}'}.txt"
        # Sanitize
        fname = "".join(c if c.isalnum() or c in "._-" else "_" for c in str(fname))
        out_file = out_dir / fname
        lines = []
        for row in range(2, sheet.max_row + 1):  # skip header
            val = sheet.cell(row=row, column=col).value
            if val is not None:
                lines.append(str(val))
        out_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
        written.append(out_file)
        log.info("Wrote %s", out_file)
    return written


# ===========================================================================
# Demo / showcase
# ===========================================================================

def run_full_demo(outdir: Union[str, Path] = None) -> None:
    """
    Create a showcase workbook that demonstrates reading, writing, styling,
    formulas, freeze panes, merged cells and a chart.
    """
    ensure_dirs()
    outdir = Path(outdir or FIGURES)
    outdir.mkdir(parents=True, exist_ok=True)

    # --- Showcase workbook ---
    wb = create_workbook("Demo Data")
    ws = wb.active

    # Title (merged)
    merge_cells(ws, "A1:D1")
    ws["A1"] = "Excel Spreadsheets Toolkit – Showcase"
    apply_font(ws["A1"], size=16, bold=True, color="1F4E79")
    ws["A1"].alignment = Alignment(horizontal="center")

    # Headers
    headers = ["Month", "Revenue", "Expenses", "Profit"]
    write_cells(ws, [headers], start_row=3)
    style_header_row(ws, 3)

    # Sample data + formulas
    months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun"]
    revenues = [12000, 15000, 13200, 17800, 16500, 19200]
    expenses = [8000, 9200, 8700, 11000, 9800, 11500]
    for i, (m, r, e) in enumerate(zip(months, revenues, expenses), start=4):
        ws.cell(row=i, column=1, value=m)
        ws.cell(row=i, column=2, value=r)
        ws.cell(row=i, column=3, value=e)
        set_formula(ws, f"D{i}", f"=B{i}-C{i}")

    # Totals row
    total_row = 10
    ws.cell(row=total_row, column=1, value="TOTAL").font = Font(bold=True)
    set_formula(ws, f"B{total_row}", f"=SUM(B4:B9)")
    set_formula(ws, f"C{total_row}", f"=SUM(C4:C9)")
    set_formula(ws, f"D{total_row}", f"=SUM(D4:D9)")
    for col in range(1, 5):
        ws.cell(row=total_row, column=col).font = Font(bold=True)
        ws.cell(row=total_row, column=col).fill = PatternFill("solid", fgColor="E2EFDA")

    auto_column_width(ws)
    freeze_header(ws, "A4")
    set_row_height(ws, 1, 30)

    # Chart
    data_ref = Reference(ws, min_col=2, min_row=3, max_col=3, max_row=9)
    cats_ref = Reference(ws, min_col=1, min_row=4, max_row=9)
    add_bar_chart(ws, data_ref, cats_ref, title="Revenue vs Expenses", anchor="F3")

    demo_path = outdir / "excel_toolkit_showcase.xlsx"
    save_workbook(wb, demo_path)
    log.info("Demo showcase written to %s", demo_path)

    # Also run a couple of the project functions quickly
    census_path = DATA / "censuspopdata_synth.xlsx"
    if census_path.exists():
        data = read_census_data(census_path)
        write_census_py(data, outdir / "census_summary.py")
        census_summary_table(data, outdir / "census_summary.xlsx")

    produce_path = DATA / "produceSales_synth.xlsx"
    if produce_path.exists():
        update_produce_prices(produce_path, out_path=outdir / "produce_updated.xlsx")

    make_multiplication_table(6, outdir / "multitable_6x6.xlsx")
    log.info("Full demo complete. Files in %s", outdir)


# ===========================================================================
# CLI
# ===========================================================================

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Extended Excel Spreadsheets Toolkit (Automate the Boring Stuff Ch.13)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples
--------
  %(prog)s demo
  %(prog)s census --input data/censuspopdata_synth.xlsx
  %(prog)s update-produce --input data/produceSales_synth.xlsx
  %(prog)s multitable 10
  %(prog)s blank-rows 3 2 --input data/example.xlsx
  %(prog)s invert --input data/example.xlsx
  %(prog)s text2sheet data/fruits.txt data/veggies.txt data/numbers.txt
  %(prog)s sheet2text --input data/example.xlsx --outdir /tmp/cols
        """,
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    # demo
    sub.add_parser("demo", help="Run full showcase (styles, formulas, chart, projects)")

    # census
    pc = sub.add_parser("census", help="Aggregate census population by county")
    pc.add_argument("--input", "-i", default=str(DATA / "censuspopdata_synth.xlsx"))
    pc.add_argument("--outdir", "-o", default=str(FIGURES))

    # update-produce
    pu = sub.add_parser("update-produce", help="Correct produce unit prices")
    pu.add_argument("--input", "-i", default=str(DATA / "produceSales_synth.xlsx"))
    pu.add_argument("--outdir", "-o", default=str(FIGURES))

    # multitable
    pm = sub.add_parser("multitable", help="Create N×N multiplication table")
    pm.add_argument("n", type=int, help="Size of the table (1-50)")
    pm.add_argument("--outdir", "-o", default=str(FIGURES))

    # blank-rows
    pb = sub.add_parser("blank-rows", help="Insert M blank rows starting at row N")
    pb.add_argument("n", type=int, help="Start row (1-based)")
    pb.add_argument("m", type=int, help="Number of blank rows to insert")
    pb.add_argument("--input", "-i", required=True)
    pb.add_argument("--outdir", "-o", default=str(FIGURES))

    # invert
    pi = sub.add_parser("invert", help="Transpose rows ↔ columns")
    pi.add_argument("--input", "-i", required=True)
    pi.add_argument("--outdir", "-o", default=str(FIGURES))

    # text2sheet
    pt = sub.add_parser("text2sheet", help="Text files → columns of a spreadsheet")
    pt.add_argument("files", nargs="+", help="One or more .txt files")
    pt.add_argument("--outdir", "-o", default=str(FIGURES))

    # sheet2text
    ps = sub.add_parser("sheet2text", help="Each column → its own .txt file")
    ps.add_argument("--input", "-i", required=True)
    ps.add_argument("--outdir", "-o", default="text_columns")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    ensure_dirs()
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.cmd == "demo":
            run_full_demo()
        elif args.cmd == "census":
            data = read_census_data(args.input)
            outdir = Path(args.outdir)
            outdir.mkdir(parents=True, exist_ok=True)
            write_census_py(data, outdir / "census_summary.py")
            census_summary_table(data, outdir / "census_summary.xlsx")
            # Print a tiny sample
            for state in list(data)[:2]:
                for county in list(data[state])[:2]:
                    print(f"{state} / {county}: {data[state][county]}")
        elif args.cmd == "update-produce":
            out = Path(args.outdir) / "produce_updated.xlsx"
            update_produce_prices(args.input, out_path=out)
        elif args.cmd == "multitable":
            out = Path(args.outdir) / f"multitable_{args.n}x{args.n}.xlsx"
            make_multiplication_table(args.n, out)
        elif args.cmd == "blank-rows":
            out = Path(args.outdir) / f"blank_rows_{args.n}_{args.m}.xlsx"
            insert_blank_rows(args.input, args.n, args.m, out)
        elif args.cmd == "invert":
            out = Path(args.outdir) / "inverted.xlsx"
            invert_cells(args.input, out)
        elif args.cmd == "text2sheet":
            out = Path(args.outdir) / "from_text_files.xlsx"
            text_files_to_spreadsheet(args.files, out)
        elif args.cmd == "sheet2text":
            spreadsheet_to_text_files(args.input, args.outdir)
        else:
            parser.error(f"Unknown command: {args.cmd}")
        return 0
    except Exception as exc:
        log.exception("Command failed")
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
