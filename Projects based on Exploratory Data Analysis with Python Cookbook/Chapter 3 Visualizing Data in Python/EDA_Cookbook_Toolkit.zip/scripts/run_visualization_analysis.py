#!/usr/bin/env python3
"""
Run a full data-visualization demonstration on the Amsterdam House Prices sample.

Usage:
    python run_visualization_analysis.py [--data PATH] [--n 10] [--no-show]

Expects HousingPricesData.csv in the data/ folder (or pass --data).
Produces figures under reports/figures/ and prints a summary.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from data_visualization import (
    prepare_house_price_data,
    top_n,
    plot_dual_bar_matplotlib,
    plot_dual_bar_seaborn,
    plot_histogram,
    plot_scatter,
    plot_correlation_heatmap,
    plot_top_n_plotnine,
    plot_top_n_bokeh,
    plot_dual_bar_bokeh,
    visualization_pipeline,
    print_summary,
    HAS_PLOTNINE,
    HAS_BOKEH,
)


def main(data_path: Path, n: int, show: bool, output_dir: Path) -> None:
    print("\n>>> 1. Preparing house-price data (load, subset, PriceperSqm)")
    df = prepare_house_price_data(data_path)
    print(df.head())

    print(f"\n>>> 2. Top {n} by absolute Price")
    top_price = top_n(df, "Price", n=n, label_col="Zip")
    print(top_price[["Zip", "Price", "Area", "Room", "PriceperSqm"]].to_string(index=False))

    print(f"\n>>> 3. Top {n} by Price per m²")
    top_pps = top_n(df, "PriceperSqm", n=n, label_col="Zip")
    print(top_pps[["Zip", "Price", "Area", "Room", "PriceperSqm"]].to_string(index=False))

    output_dir.mkdir(parents=True, exist_ok=True)

    print("\n>>> 4. Matplotlib dual bar charts")
    plot_dual_bar_matplotlib(
        top_price,
        value_cols=["Price", "PriceperSqm"],
        titles=[
            f"Top {n} Areas with the highest house prices",
            f"Top {n} Areas with the highest price per sqm",
        ],
        ylabels=["House prices (€)", "House prices per sqm (€)"],
        save_path=output_dir / "matplotlib_dual.png",
    )
    if show:
        import matplotlib.pyplot as plt
        plt.show()

    print("\n>>> 5. Seaborn dual bar charts")
    plot_dual_bar_seaborn(
        top_price,
        value_cols=["Price", "PriceperSqm"],
        titles=[
            f"Top {n} Areas with the highest house prices (Seaborn)",
            f"Top {n} Areas with the highest price per sqm (Seaborn)",
        ],
        ylabels=["House prices (€)", "House prices per sqm (€)"],
        save_path=output_dir / "seaborn_dual.png",
    )
    if show:
        import matplotlib.pyplot as plt
        plt.show()

    print("\n>>> 6. Extra diagnostics – histogram, scatter, correlation")
    plot_histogram(df, "Price", title="Distribution of House Prices",
                   save_path=output_dir / "hist_price.png")
    plot_scatter(df, "Area", "Price", title="Price versus Area",
                 save_path=output_dir / "scatter_price_area.png")
    plot_correlation_heatmap(
        df, columns=["Price", "Area", "Room", "PriceperSqm"],
        save_path=output_dir / "corr_heatmap.png",
    )
    if show:
        import matplotlib.pyplot as plt
        plt.show()

    if HAS_PLOTNINE:
        print("\n>>> 7. plotnine / GGPLOT bar chart")
        p = plot_top_n_plotnine(
            top_price, value_col="Price",
            title=f"Top {n} Areas – Highest House Prices (plotnine)",
            ylabel="House prices (€)",
            save_path=output_dir / "plotnine_price.png",
        )
        print("  saved plotnine figure")
    else:
        print("\n>>> 7. plotnine not installed – skipping")

    if HAS_BOKEH:
        print("\n>>> 8. Bokeh interactive charts")
        plot_top_n_bokeh(
            top_price, value_col="Price",
            title=f"Top {n} Areas – Highest House Prices (Bokeh)",
            ylabel="House prices (€)",
            notebook=False,
            save_path=output_dir / "bokeh_price.html",
        )
        plot_dual_bar_bokeh(
            top_price,
            value_cols=["Price", "PriceperSqm"],
            titles=[
                f"Top {n} – highest prices",
                f"Top {n} – highest price/m²",
            ],
            notebook=False,
            save_path=output_dir / "bokeh_dual.html",
        )
        print("  saved Bokeh HTML files")
    else:
        print("\n>>> 8. bokeh not installed – skipping")

    print("\n>>> 9. Full pipeline summary")
    summary = visualization_pipeline(
        data_path, n_top=n, output_dir=output_dir, show=False
    )
    print_summary(summary)
    print(f"\nAll figures written to: {output_dir.resolve()}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Chapter 3 visualization demos")
    parser.add_argument(
        "--data",
        type=Path,
        default=ROOT / "data" / "HousingPricesData.csv",
        help="Path to HousingPricesData.csv",
    )
    parser.add_argument("--n", type=int, default=10, help="Top-N rows to chart")
    parser.add_argument(
        "--no-show", action="store_true", help="Do not call plt.show()"
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=ROOT / "reports" / "figures",
        help="Directory for saved figures",
    )
    args = parser.parse_args()
    main(args.data, args.n, show=not args.no_show, output_dir=args.output)
