"""
Data Visualization Module for Exploratory Data Analysis
=======================================================
Reusable functions implementing and extending the material from
"Exploratory Data Analysis with Python Cookbook" Chapter 3:
Visualizing Data in Python.

Covers the book recipes:
- Preparing for visualization (inspect + feature engineering)
- Visualizing data in Matplotlib (bar charts, subplots)
- Visualizing data in Seaborn (styled bar plots)
- Visualizing data in GGPLOT / plotnine
- Visualizing data in Bokeh (interactive charts & gridplots)

Enhancements beyond the book recipes:
- Consistent data-prep helpers with validation
- Top-N ranking utilities that work for any numeric column
- Multi-library bar-chart wrappers that share the same API
- Histogram, scatter, box-plot, and correlation-heatmap helpers
- Automatic figure saving with configurable DPI / formats
- Optional interactive Bokeh hover tools and linked brushing
- Theme / style context managers for reproducible aesthetics
- Pipeline that prepares data + generates a standard dashboard of charts
- Summary statistics table suitable for inclusion in reports / spreadsheets

Dependencies:
    required : pandas, numpy, matplotlib, seaborn
    optional : plotnine, bokeh  (functions gracefully degrade if missing)

Usage example
-------------
    from data_visualization import (
        prepare_house_price_data,
        top_n,
        plot_top_n_matplotlib,
        plot_top_n_seaborn,
        plot_top_n_plotnine,
        plot_top_n_bokeh,
        visualization_pipeline,
    )
    df = prepare_house_price_data("data/HousingPricesData.csv")
    top = top_n(df, "Price", n=10)
    plot_top_n_matplotlib(top, value_col="Price", title="Top 10 prices")
"""

from __future__ import annotations

import warnings
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

# Optional backends
try:
    from plotnine import (
        ggplot,
        aes,
        geom_bar,
        geom_col,
        labs,
        theme,
        element_text,
        scale_x_discrete,
        theme_bw,
    )
    HAS_PLOTNINE = True
except ImportError:  # pragma: no cover
    HAS_PLOTNINE = False

try:
    from bokeh.plotting import figure, show, output_notebook, output_file, save
    from bokeh.layouts import gridplot, column, row
    from bokeh.models import ColumnDataSource, HoverTool
    from bokeh.io import curdoc
    HAS_BOKEH = True
except ImportError:  # pragma: no cover
    HAS_BOKEH = False


ArrayLike = Union[pd.Series, np.ndarray, List, tuple]
DataFrameLike = pd.DataFrame
PathLike = Union[str, Path]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _ensure_df(data: Any, name: str = "data") -> pd.DataFrame:
    if isinstance(data, pd.DataFrame):
        return data.copy()
    if isinstance(data, (pd.Series, dict, list, np.ndarray)):
        return pd.DataFrame(data)
    raise TypeError(f"{name} must be a pandas DataFrame (or convertible), got {type(data)}")


def _validate_columns(df: pd.DataFrame, cols: Sequence[str], context: str = "") -> None:
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise KeyError(f"Columns not found{(' in ' + context) if context else ''}: {missing}")


def _ensure_dir(path: PathLike) -> Path:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------------------------------------------
# 1. Preparing for visualization (book recipe + extensions)
# ---------------------------------------------------------------------------

def load_and_subset(
    path: PathLike,
    columns: Optional[Sequence[str]] = None,
) -> pd.DataFrame:
    """
    Load a CSV and optionally keep only the requested columns.

    Parameters
    ----------
    path : str or Path
        Location of the CSV (e.g. data/HousingPricesData.csv).
    columns : list of str, optional
        Columns to retain. Defaults to ['Zip', 'Price', 'Area', 'Room'].

    Returns
    -------
    DataFrame
    """
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Data file not found: {path}")
    df = pd.read_csv(path)
    if columns is None:
        columns = ["Zip", "Price", "Area", "Room"]
    available = [c for c in columns if c in df.columns]
    if not available:
        raise KeyError(f"None of the requested columns found in {path}: {columns}")
    return df[available].copy()


def inspect_dataframe(df: pd.DataFrame, n: int = 5) -> Dict[str, Any]:
    """
    Quick inspection used before visualisation.

    Returns a dictionary with head, shape, dtypes and missing-value counts
    so it can be printed or serialised into a report.
    """
    df = _ensure_df(df)
    return {
        "head": df.head(n),
        "shape": df.shape,
        "dtypes": df.dtypes.to_dict(),
        "missing": df.isna().sum().to_dict(),
        "memory_mb": round(df.memory_usage(deep=True).sum() / 1e6, 3),
    }


def add_price_per_sqm(
    df: pd.DataFrame,
    price_col: str = "Price",
    area_col: str = "Area",
    new_col: str = "PriceperSqm",
) -> pd.DataFrame:
    """
    Create the classic real-estate metric Price / Area.

    Matches the book recipe exactly while adding division-by-zero protection.
    """
    df = _ensure_df(df)
    _validate_columns(df, [price_col, area_col])
    out = df.copy()
    area = out[area_col].replace(0, np.nan)
    out[new_col] = out[price_col] / area
    return out


def prepare_house_price_data(
    path: PathLike = "data/HousingPricesData.csv",
    columns: Optional[Sequence[str]] = None,
) -> pd.DataFrame:
    """
    End-to-end preparation that mirrors the first notebook:
    load → subset → inspect (printed) → add PriceperSqm.
    """
    df = load_and_subset(path, columns)
    info = inspect_dataframe(df)
    print(f"Loaded shape: {info['shape']}")
    print(f"Dtypes:\n{pd.Series(info['dtypes'])}")
    print(f"Missing values: {info['missing']}")
    df = add_price_per_sqm(df)
    return df


def top_n(
    df: pd.DataFrame,
    value_col: str,
    n: int = 10,
    ascending: bool = False,
    label_col: Optional[str] = None,
) -> pd.DataFrame:
    """
    Return the top (or bottom) n rows sorted by a numeric column.
    Useful for the bar-chart recipes that always start with a sorted subset.
    """
    df = _ensure_df(df)
    _validate_columns(df, [value_col])
    out = df.sort_values(value_col, ascending=ascending).head(n).copy()
    if label_col and label_col in out.columns:
        # Keep categorical order for plotting libraries that respect it
        out[label_col] = pd.Categorical(
            out[label_col], categories=out[label_col].tolist(), ordered=True
        )
    return out.reset_index(drop=True)


# ---------------------------------------------------------------------------
# 2. Matplotlib
# ---------------------------------------------------------------------------

def plot_top_n_matplotlib(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_col: str = "Price",
    title: str = "Top N items",
    ylabel: str = "Value",
    figsize: Tuple[float, float] = (12, 6),
    color: str = "#1f77b4",
    rotation: int = 45,
    ax: Optional[plt.Axes] = None,
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """
    Classic vertical bar chart using pure Matplotlib (book recipe style).
    """
    df = _ensure_df(df)
    _validate_columns(df, [category_col, value_col])
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    x = df[category_col].astype(str)
    y = df[value_col]
    bars = ax.bar(x, y, color=color)
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_xlabel(category_col, fontsize=11)
    ax.set_ylabel(ylabel, fontsize=11)
    ax.tick_params(axis="x", rotation=rotation, labelsize=9)
    ax.tick_params(axis="y", labelsize=9)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


def plot_dual_bar_matplotlib(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_cols: Sequence[str] = ("Price", "PriceperSqm"),
    titles: Optional[Sequence[str]] = None,
    ylabels: Optional[Sequence[str]] = None,
    figsize: Tuple[float, float] = (16, 6),
    save_path: Optional[PathLike] = None,
) -> plt.Figure:
    """
    Side-by-side bar charts (the exact pattern used in the Matplotlib notebook).
    """
    df = _ensure_df(df)
    n = len(value_cols)
    fig, axes = plt.subplots(1, n, figsize=figsize)
    if n == 1:
        axes = [axes]
    titles = titles or [f"Top items by {c}" for c in value_cols]
    ylabels = ylabels or list(value_cols)
    for ax, col, title, ylab in zip(axes, value_cols, titles, ylabels):
        plot_top_n_matplotlib(
            df, category_col=category_col, value_col=col,
            title=title, ylabel=ylab, ax=ax
        )
    fig.tight_layout()
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return fig


# ---------------------------------------------------------------------------
# 3. Seaborn
# ---------------------------------------------------------------------------

def plot_top_n_seaborn(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_col: str = "Price",
    title: str = "Top N items",
    ylabel: str = "Value",
    figsize: Tuple[float, float] = (12, 6),
    palette: str = "Blues_d",
    ax: Optional[plt.Axes] = None,
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """
    Seaborn barplot wrapper that matches the book notebook aesthetics.
    """
    df = _ensure_df(df)
    _validate_columns(df, [category_col, value_col])
    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.figure

    sns.barplot(
        data=df, x=category_col, y=value_col, ax=ax, palette=palette, hue=category_col,
        legend=False
    )
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_xlabel(category_col)
    ax.set_ylabel(ylabel)
    ax.tick_params(axis="x", rotation=45)
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


def plot_dual_bar_seaborn(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_cols: Sequence[str] = ("Price", "PriceperSqm"),
    titles: Optional[Sequence[str]] = None,
    ylabels: Optional[Sequence[str]] = None,
    figsize: Tuple[float, float] = (16, 6),
    save_path: Optional[PathLike] = None,
) -> plt.Figure:
    """Side-by-side Seaborn barplots (book notebook pattern)."""
    df = _ensure_df(df)
    n = len(value_cols)
    fig, axes = plt.subplots(1, n, figsize=figsize)
    if n == 1:
        axes = [axes]
    titles = titles or [f"Top items by {c}" for c in value_cols]
    ylabels = ylabels or list(value_cols)
    for ax, col, title, ylab in zip(axes, value_cols, titles, ylabels):
        plot_top_n_seaborn(
            df, category_col=category_col, value_col=col,
            title=title, ylabel=ylab, ax=ax
        )
    fig.tight_layout()
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return fig


# ---------------------------------------------------------------------------
# 4. plotnine / GGPLOT
# ---------------------------------------------------------------------------

def plot_top_n_plotnine(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_col: str = "Price",
    title: str = "Top N items",
    ylabel: str = "Value",
    figsize: Tuple[float, float] = (12, 6),
    save_path: Optional[PathLike] = None,
):
    """
    ggplot-style bar chart via plotnine.
    Returns a plotnine ggplot object (call .draw() or print it in a notebook).
    """
    if not HAS_PLOTNINE:
        raise ImportError(
            "plotnine is required for GGPLOT visuals. Install with: pip install plotnine"
        )
    df = _ensure_df(df)
    _validate_columns(df, [category_col, value_col])
    # Preserve order
    order = df[category_col].astype(str).tolist()
    p = (
        ggplot(df, aes(x=category_col, y=value_col))
        + geom_col(fill="#1f77b4")
        + scale_x_discrete(limits=order)
        + labs(title=title, x=category_col, y=ylabel)
        + theme(
            figure_size=figsize,
            axis_title=element_text(face="bold", size=11),
            axis_text=element_text(size=9),
            plot_title=element_text(face="bold", size=13),
            axis_text_x=element_text(rotation=45, hjust=1),
        )
    )
    if save_path:
        p.save(str(_ensure_dir(save_path)), dpi=150, verbose=False)
    return p


# ---------------------------------------------------------------------------
# 5. Bokeh
# ---------------------------------------------------------------------------

def plot_top_n_bokeh(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_col: str = "Price",
    title: str = "Top N items",
    ylabel: str = "Value",
    width: int = 700,
    height: int = 420,
    color: str = "#1f77b4",
    notebook: bool = True,
    save_path: Optional[PathLike] = None,
):
    """
    Interactive vertical bar chart with hover tooltips.
    Returns a Bokeh figure.
    """
    if not HAS_BOKEH:
        raise ImportError(
            "bokeh is required for interactive visuals. Install with: pip install bokeh"
        )
    df = _ensure_df(df)
    _validate_columns(df, [category_col, value_col])
    cats = df[category_col].astype(str).tolist()
    source = ColumnDataSource(data={
        "x": cats,
        "top": df[value_col].tolist(),
        category_col: cats,
        value_col: df[value_col].tolist(),
    })
    p = figure(
        x_range=cats,
        width=width,
        height=height,
        title=title,
        x_axis_label=category_col,
        y_axis_label=ylabel,
        tools="pan,wheel_zoom,box_zoom,reset,save",
    )
    p.vbar(x="x", top="top", width=0.8, source=source, color=color)
    hover = HoverTool(tooltips=[
        (category_col, f"@{{{category_col}}}"),
        (value_col, f"@{{{value_col}}}{{0,0.00}}"),
    ])
    p.add_tools(hover)
    p.xaxis.major_label_orientation = 0.8
    p.title.text_font_size = "13pt"
    p.xaxis.axis_label_text_font_size = "11pt"
    p.yaxis.axis_label_text_font_size = "11pt"
    if save_path:
        output_file(str(_ensure_dir(save_path)))
        save(p)
    elif notebook:
        try:
            output_notebook(hide_banner=True)
        except Exception:
            pass
    return p


def plot_dual_bar_bokeh(
    df: pd.DataFrame,
    category_col: str = "Zip",
    value_cols: Sequence[str] = ("Price", "PriceperSqm"),
    titles: Optional[Sequence[str]] = None,
    ylabels: Optional[Sequence[str]] = None,
    width: int = 480,
    height: int = 400,
    notebook: bool = True,
    save_path: Optional[PathLike] = None,
):
    """
    Side-by-side interactive Bokeh charts (matches the gridplot recipe).
    """
    if not HAS_BOKEH:
        raise ImportError("bokeh is required. Install with: pip install bokeh")
    titles = titles or [f"Top by {c}" for c in value_cols]
    ylabels = ylabels or list(value_cols)
    figs = []
    for col, title, ylab in zip(value_cols, titles, ylabels):
        figs.append(
            plot_top_n_bokeh(
                df, category_col=category_col, value_col=col,
                title=title, ylabel=ylab, width=width, height=height,
                notebook=False,
            )
        )
    layout = gridplot([figs], toolbar_location="above")
    if save_path:
        output_file(str(_ensure_dir(save_path)))
        save(layout)
    elif notebook:
        try:
            output_notebook(hide_banner=True)
        except Exception:
            pass
    return layout


# ---------------------------------------------------------------------------
# Extra chart helpers (enhancements)
# ---------------------------------------------------------------------------

def plot_histogram(
    df: pd.DataFrame,
    column: str,
    bins: int = 30,
    title: Optional[str] = None,
    figsize: Tuple[float, float] = (8, 5),
    kde: bool = True,
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """Distribution plot with optional KDE – useful before any ranking chart."""
    df = _ensure_df(df)
    _validate_columns(df, [column])
    fig, ax = plt.subplots(figsize=figsize)
    sns.histplot(df[column].dropna(), bins=bins, kde=kde, ax=ax, color="#4c72b0")
    ax.set_title(title or f"Distribution of {column}")
    ax.set_xlabel(column)
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


def plot_scatter(
    df: pd.DataFrame,
    x: str,
    y: str,
    hue: Optional[str] = None,
    title: Optional[str] = None,
    figsize: Tuple[float, float] = (8, 6),
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """Scatter plot for exploring relationships (e.g. Area vs Price)."""
    df = _ensure_df(df)
    cols = [x, y] + ([hue] if hue else [])
    _validate_columns(df, cols)
    fig, ax = plt.subplots(figsize=figsize)
    sns.scatterplot(data=df, x=x, y=y, hue=hue, ax=ax, alpha=0.6)
    ax.set_title(title or f"{y} vs {x}")
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


def plot_boxplot(
    df: pd.DataFrame,
    column: str,
    by: Optional[str] = None,
    title: Optional[str] = None,
    figsize: Tuple[float, float] = (8, 5),
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """Box plot for a numeric column, optionally grouped."""
    df = _ensure_df(df)
    _validate_columns(df, [column] + ([by] if by else []))
    fig, ax = plt.subplots(figsize=figsize)
    if by:
        sns.boxplot(data=df, x=by, y=column, ax=ax)
        ax.tick_params(axis="x", rotation=45)
    else:
        sns.boxplot(y=df[column], ax=ax)
    ax.set_title(title or f"Box plot of {column}")
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


def plot_correlation_heatmap(
    df: pd.DataFrame,
    columns: Optional[Sequence[str]] = None,
    title: str = "Correlation matrix",
    figsize: Tuple[float, float] = (7, 6),
    save_path: Optional[PathLike] = None,
) -> plt.Axes:
    """Pearson correlation heatmap for numeric columns."""
    df = _ensure_df(df)
    if columns is None:
        num = df.select_dtypes(include=[np.number])
    else:
        _validate_columns(df, columns)
        num = df[list(columns)]
    corr = num.corr()
    fig, ax = plt.subplots(figsize=figsize)
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="RdBu_r", center=0, ax=ax)
    ax.set_title(title)
    if save_path:
        fig.savefig(_ensure_dir(save_path), dpi=150, bbox_inches="tight")
    return ax


# ---------------------------------------------------------------------------
# Style helpers
# ---------------------------------------------------------------------------

@contextmanager
def seaborn_theme(style: str = "whitegrid", context: str = "notebook", font_scale: float = 1.1):
    """Temporary Seaborn theme that restores previous settings on exit."""
    prev = sns.axes_style(), sns.plotting_context()
    sns.set_theme(style=style, context=context, font_scale=font_scale)
    try:
        yield
    finally:
        sns.set_style(prev[0])
        sns.set_context(prev[1])


# ---------------------------------------------------------------------------
# High-level pipeline
# ---------------------------------------------------------------------------

def visualization_pipeline(
    path: PathLike = "data/HousingPricesData.csv",
    n_top: int = 10,
    output_dir: PathLike = "reports/figures",
    show: bool = True,
) -> Dict[str, Any]:
    """
    Full demonstration pipeline:
    1. Prepare data
    2. Rank top-N by Price and by PriceperSqm
    3. Generate Matplotlib, Seaborn dual-bar charts
    4. Generate distribution / scatter / correlation extras
    5. Optionally generate plotnine & Bokeh charts
    6. Return a summary dict useful for reports
    """
    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = prepare_house_price_data(path)
    top_price = top_n(df, "Price", n=n_top, label_col="Zip")
    top_pps = top_n(df, "PriceperSqm", n=n_top, label_col="Zip")

    summary = {
        "n_rows": len(df),
        "columns": list(df.columns),
        "top_price": top_price,
        "top_price_per_sqm": top_pps,
        "price_stats": df["Price"].describe().to_dict(),
        "pps_stats": df["PriceperSqm"].describe().to_dict(),
    }

    # Matplotlib dual
    fig_m = plot_dual_bar_matplotlib(
        top_price,
        value_cols=["Price", "PriceperSqm"],
        titles=[
            f"Top {n_top} Areas – Highest House Prices",
            f"Top {n_top} Areas – Highest Price per m²",
        ],
        ylabels=["House price (€)", "Price per m² (€)"],
        save_path=out_dir / "matplotlib_dual_bars.png",
    )
    if show:
        plt.show()
    else:
        plt.close(fig_m)

    # Seaborn dual
    with seaborn_theme():
        fig_s = plot_dual_bar_seaborn(
            top_price,
            value_cols=["Price", "PriceperSqm"],
            titles=[
                f"Top {n_top} Areas – Highest House Prices (Seaborn)",
                f"Top {n_top} Areas – Highest Price per m² (Seaborn)",
            ],
            ylabels=["House price (€)", "Price per m² (€)"],
            save_path=out_dir / "seaborn_dual_bars.png",
        )
    if show:
        plt.show()
    else:
        plt.close(fig_s)

    # Extra diagnostics
    plot_histogram(df, "Price", title="House Price Distribution",
                   save_path=out_dir / "price_histogram.png")
    if show:
        plt.show()
    else:
        plt.close()

    plot_scatter(df, "Area", "Price", title="Price vs Area",
                 save_path=out_dir / "price_vs_area.png")
    if show:
        plt.show()
    else:
        plt.close()

    plot_correlation_heatmap(
        df, columns=["Price", "Area", "Room", "PriceperSqm"],
        save_path=out_dir / "correlation_heatmap.png",
    )
    if show:
        plt.show()
    else:
        plt.close()

    # Optional libraries
    if HAS_PLOTNINE:
        try:
            p = plot_top_n_plotnine(
                top_price, value_col="Price",
                title=f"Top {n_top} Areas – Highest House Prices (plotnine)",
                ylabel="House price (€)",
                save_path=out_dir / "plotnine_top_price.png",
            )
            summary["plotnine"] = "ok"
        except Exception as e:
            summary["plotnine"] = str(e)
    else:
        summary["plotnine"] = "not installed"

    if HAS_BOKEH:
        try:
            plot_top_n_bokeh(
                top_price, value_col="Price",
                title=f"Top {n_top} Areas – Highest House Prices (Bokeh)",
                ylabel="House price (€)",
                notebook=False,
                save_path=out_dir / "bokeh_top_price.html",
            )
            summary["bokeh"] = "ok"
        except Exception as e:
            summary["bokeh"] = str(e)
    else:
        summary["bokeh"] = "not installed"

    summary["figures_dir"] = str(out_dir)
    return summary


def print_summary(summary: Dict[str, Any]) -> None:
    """Pretty-print the pipeline summary."""
    print("\n" + "=" * 60)
    print("VISUALIZATION PIPELINE SUMMARY")
    print("=" * 60)
    print(f"Rows          : {summary['n_rows']}")
    print(f"Columns       : {summary['columns']}")
    print(f"Figures saved : {summary.get('figures_dir')}")
    print(f"plotnine      : {summary.get('plotnine')}")
    print(f"bokeh         : {summary.get('bokeh')}")
    print("\nPrice statistics:")
    for k, v in summary["price_stats"].items():
        print(f"  {k:>8}: {v:,.2f}" if isinstance(v, (int, float)) else f"  {k}: {v}")
    print("\nTop 5 by Price:")
    print(summary["top_price"][["Zip", "Price", "Area", "PriceperSqm"]].head().to_string(index=False))
    print("=" * 60)


if __name__ == "__main__":
    # Quick self-test when run directly
    root = Path(__file__).resolve().parents[1]
    data_path = root / "data" / "HousingPricesData.csv"
    if data_path.exists():
        s = visualization_pipeline(data_path, show=False)
        print_summary(s)
    else:
        print(f"Data file not found at {data_path}")
