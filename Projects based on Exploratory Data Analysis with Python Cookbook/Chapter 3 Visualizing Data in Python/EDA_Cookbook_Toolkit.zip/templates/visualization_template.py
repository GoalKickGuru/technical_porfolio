"""
Reusable Visualization Template
================================
Copy this file and adapt the DATA_PATH / COLUMN settings for any new dataset.
All heavy lifting is done by the functions in scripts/data_visualization.py.
"""

from __future__ import annotations

import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration – edit these for your project
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]          # project root
sys.path.insert(0, str(ROOT / "scripts"))

DATA_PATH = ROOT / "data" / "HousingPricesData.csv"  # change me
CATEGORY_COL = "Zip"                                 # categorical / label column
VALUE_COLS = ["Price", "PriceperSqm"]                # numeric columns to rank
N_TOP = 10
OUTPUT_DIR = ROOT / "reports" / "figures"
SHOW_PLOTS = True

# ---------------------------------------------------------------------------
# Imports
# ---------------------------------------------------------------------------
from data_visualization import (
    prepare_house_price_data,
    top_n,
    plot_dual_bar_matplotlib,
    plot_dual_bar_seaborn,
    plot_histogram,
    plot_scatter,
    plot_correlation_heatmap,
    plot_top_n_plotnine,
    plot_top_n_bokeh,
    visualization_pipeline,
    print_summary,
    HAS_PLOTNINE,
    HAS_BOKEH,
)

# ---------------------------------------------------------------------------
# 1. Load & prepare
# ---------------------------------------------------------------------------
df = prepare_house_price_data(DATA_PATH)
print(df.head())

# ---------------------------------------------------------------------------
# 2. Rank
# ---------------------------------------------------------------------------
top = top_n(df, VALUE_COLS[0], n=N_TOP, label_col=CATEGORY_COL)
print(f"\nTop {N_TOP} by {VALUE_COLS[0]}:")
print(top[[CATEGORY_COL] + VALUE_COLS].to_string(index=False))

# ---------------------------------------------------------------------------
# 3. Matplotlib dual bars
# ---------------------------------------------------------------------------
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
plot_dual_bar_matplotlib(
    top,
    category_col=CATEGORY_COL,
    value_cols=VALUE_COLS,
    titles=[f"Top {N_TOP} by {c}" for c in VALUE_COLS],
    ylabels=VALUE_COLS,
    save_path=OUTPUT_DIR / "template_matplotlib.png",
)

# ---------------------------------------------------------------------------
# 4. Seaborn dual bars
# ---------------------------------------------------------------------------
plot_dual_bar_seaborn(
    top,
    category_col=CATEGORY_COL,
    value_cols=VALUE_COLS,
    titles=[f"Top {N_TOP} by {c} (Seaborn)" for c in VALUE_COLS],
    ylabels=VALUE_COLS,
    save_path=OUTPUT_DIR / "template_seaborn.png",
)

# ---------------------------------------------------------------------------
# 5. Diagnostic charts
# ---------------------------------------------------------------------------
plot_histogram(df, VALUE_COLS[0], save_path=OUTPUT_DIR / "template_hist.png")
plot_scatter(df, "Area", VALUE_COLS[0], save_path=OUTPUT_DIR / "template_scatter.png")
plot_correlation_heatmap(
    df, columns=["Price", "Area", "Room", "PriceperSqm"],
    save_path=OUTPUT_DIR / "template_corr.png",
)

# ---------------------------------------------------------------------------
# 6. Optional libraries
# ---------------------------------------------------------------------------
if HAS_PLOTNINE:
    plot_top_n_plotnine(
        top, category_col=CATEGORY_COL, value_col=VALUE_COLS[0],
        title=f"Top {N_TOP} (plotnine)",
        save_path=OUTPUT_DIR / "template_plotnine.png",
    )

if HAS_BOKEH:
    plot_top_n_bokeh(
        top, category_col=CATEGORY_COL, value_col=VALUE_COLS[0],
        title=f"Top {N_TOP} (Bokeh)",
        notebook=False,
        save_path=OUTPUT_DIR / "template_bokeh.html",
    )

# ---------------------------------------------------------------------------
# 7. One-liner full pipeline (alternative)
# ---------------------------------------------------------------------------
# summary = visualization_pipeline(DATA_PATH, n_top=N_TOP, output_dir=OUTPUT_DIR, show=SHOW_PLOTS)
# print_summary(summary)

print(f"\nFigures written to {OUTPUT_DIR}")
if SHOW_PLOTS:
    import matplotlib.pyplot as plt
    plt.show()
