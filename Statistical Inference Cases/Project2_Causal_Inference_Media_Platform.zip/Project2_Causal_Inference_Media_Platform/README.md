# Project 2: Causal Inference – Content Topic → Pageviews

**Inference Data Scientist Portfolio Piece**  
Based on concepts from *Causal Inference for Data Science* (De Villa)

## What is inside

| File | Description |
|------|-------------|
| `Project2_Content_Topic_Causal_Inference_executed.ipynb` | **Main notebook** – fully executed with all tables, results and plots |
| `Project2_Content_Topic_Causal_Inference.ipynb` | Clean source version (no outputs) |
| `simulated_media_posts.csv` | Simulated historical dataset (2,500 posts) used in the analysis |
| `project2_naive_vs_stratified.png` | Visualization of confounding |
| `project2_crude_vs_causal.png` | Side-by-side comparison of naïve vs causal estimates |

## How to use

1. Open `Project2_Content_Topic_Causal_Inference_executed.ipynb` in Jupyter, VS Code, Google Colab, or any notebook environment.
2. The notebook is self-contained and tells a complete decision-maker story.
3. You can re-run the source notebook if you want to change parameters.

## Core insight demonstrated

- **Naïve analysis**: Sports content appears better (+10 pageviews)
- **Causal analysis (adjustment formula)**: Culture content is actually better (−19 pageviews)
- The apparent Sports advantage was an artifact of marketing’s platform assignment (confounding)

This is a practical illustration of why “correlation ≠ causation” matters for real business decisions, and how a simple simulation + DAG can prevent costly mistakes.
