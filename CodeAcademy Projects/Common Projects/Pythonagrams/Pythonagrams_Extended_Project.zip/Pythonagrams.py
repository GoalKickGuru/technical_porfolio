"""
Pythonagrams – Complete Scoring System
--------------------------------------
Dictionary-based letter scoring for the Pythonagrams game.
Includes play_word, update_point_totals, case-insensitive scoring,
alternate implementations and a simulation section.
"""

letters = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M",
           "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
points  = [1, 2, 2, 2, 1, 3, 3, 3, 1, 4, 3, 1, 2,
           3, 1, 3, 5, 1, 1, 1, 2, 3, 3, 4, 3, 5]

# 1. Build the point dictionary
letter_to_points = {letter: point for letter, point in zip(letters, points)}


def score_word(word):
    """Return total points for a word (case-insensitive)."""
    return sum(letter_to_points.get(letter.upper(), 0) for letter in word)


# 2. Game state
player_to_words = {
    "wordNerd":    ["BLUE", "EARTH", "ERASER", "ZAP"],
    "Lexi Con":    ["TENNIS", "EYES", "BELLY", "COMA"],
    "Prof Reader": ["EXIT", "MACHINE", "HUSKY", "PERIOD"]
}

player_to_points = {}


def update_point_totals():
    """Recalculate every player's total points."""
    global player_to_points
    player_to_points = {
        player: sum(score_word(w) for w in words)
        for player, words in player_to_words.items()
    }
    return player_to_points


def play_word(player, word):
    """Add a word to a player's list (creates the player if needed)."""
    if player in player_to_words:
        player_to_words[player].append(word)
    else:
        player_to_words[player] = [word]
    print(f"Added '{word}' to {player}. Now has: {player_to_words[player]}")


def best_word(player):
    """Return the highest-scoring word a player has played."""
    if player not in player_to_words or not player_to_words[player]:
        return None
    return max(player_to_words[player], key=score_word)


# ------------------------------------------------------------------
# Main demonstration
# ------------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 50)
    print("Pythonagrams Scoring System")
    print("=" * 50)

    print("\nletter_to_points (first 10 items):")
    for i, (k, v) in enumerate(letter_to_points.items()):
        if i >= 10:
            print("  ...")
            break
        print(f"  {k}: {v}")

    print(f"\nscore_word('BROWNIE') = {score_word('BROWNIE')}")  # 12
    print(f"score_word('brownie') = {score_word('brownie')}")  # also 12

    update_point_totals()
    print("\nInitial standings:")
    for player, pts in player_to_points.items():
        print(f"  {player:12} → {pts} points")

    # Extensions demo
    print("\n--- play_word demo ---")
    play_word("wordNerd", "QUIZ")
    update_point_totals()
    print("Standings after QUIZ:")
    print(player_to_points)

    print("\n--- best_word per player ---")
    for p in player_to_words:
        bw = best_word(p)
        print(f"  {p:12} → {bw} ({score_word(bw)} pts)")

    # Ranking
    ranking = sorted(player_to_points.items(), key=lambda x: x[1], reverse=True)
    print("\nRanking:")
    for place, (player, pts) in enumerate(ranking, 1):
        print(f"  {place}. {player:12} {pts} pts")

    # Simple simulation
    print("\n=== Simulation (Q/Z boosted to 10, add QUIZZES, remove COMA) ===")
    sim_letter = letter_to_points.copy()
    sim_letter["Q"] = 10
    sim_letter["Z"] = 10

    def sim_score(w):
        return sum(sim_letter.get(c.upper(), 0) for c in w)

    sim_players = {p: w[:] for p, w in {
        "wordNerd":    ["BLUE", "EARTH", "ERASER", "ZAP"],
        "Lexi Con":    ["TENNIS", "EYES", "BELLY", "COMA"],
        "Prof Reader": ["EXIT", "MACHINE", "HUSKY", "PERIOD"]
    }.items()}

    sim_players["wordNerd"].append("QUIZZES")
    sim_players["Lexi Con"].remove("COMA")

    sim_points = {p: sum(sim_score(w) for w in words) for p, words in sim_players.items()}
    for p, pts in sorted(sim_points.items(), key=lambda x: -x[1]):
        print(f"  {p:12} → {pts} pts")
