#!/usr/bin/env python3
"""
CLI runner for the Extended Web Scraping Toolkit.
Simply forwards all arguments to web_scraping.main().

Examples
--------
    python run_web_scraping.py demo
    python run_web_scraping.py map "1600 Amphitheatre Parkway, Mountain View, CA"
    python run_web_scraping.py search "beautiful soup" --max 3
    python run_web_scraping.py xkcd --max 3 --outdir reports/figures/web_scraping/xkcd
    python run_web_scraping.py verify https://nostarch.com
    python run_web_scraping.py 2048 --moves 20
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure the scripts directory is on the path when run from project root
sys.path.insert(0, str(Path(__file__).resolve().parent))

from web_scraping import main

if __name__ == "__main__":
    sys.exit(main())
