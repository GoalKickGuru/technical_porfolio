#!/usr/bin/env python3
"""
Extended Web Scraping Toolkit
=============================
Extends Chapter 12 of "Automate the Boring Stuff with Python" (2nd Edition)
by Al Sweigart – Web Scraping – with production-ready helpers, robust error
handling, logging, rate-limiting, CLI support, reusable pipelines, and
skeleton implementations of the practice projects.

Modules & techniques covered + enhancements
-------------------------------------------
1. webbrowser          – open maps / arbitrary URLs from CLI or clipboard
2. requests            – download pages & binary files with retries, sessions,
                         custom headers, and safe iter_content saving
3. BeautifulSoup (bs4) – CSS-selector parsing, attribute extraction, link
                         harvesting, text cleaning
4. searchpypi-style    – open the top-N search results of any site that returns
                         linkable results (PyPI default, extensible)
5. XKCD / comic downloader – sequential download of image galleries that
                         follow a “previous” link pattern
6. selenium            – browser automation (Firefox/Chrome), form filling,
                         clicking, special keys, element location strategies
7. Practice skeletons  – Link Verification, Image-Site Downloader, 2048 autoplayer

Usage (library)
---------------
    from web_scraping import (
        open_map, download_url, get_soup, download_xkcd_comics,
        SearchResultsOpener, SeleniumBrowser, LinkVerifier
    )

Usage (CLI – see run_web_scraping.py)
-------------------------------------
    python run_web_scraping.py map "870 Valencia St, San Francisco, CA"
    python run_web_scraping.py search "requests beautifulsoup"
    python run_web_scraping.py xkcd --max 10
    python run_web_scraping.py verify https://example.com
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union
from urllib.parse import urljoin, urlparse

# ---------------------------------------------------------------------------
# Optional / third-party imports with graceful fallback messages
# ---------------------------------------------------------------------------
try:
    import requests
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
except ImportError:  # pragma: no cover
    requests = None  # type: ignore

try:
    import bs4
    from bs4 import BeautifulSoup
except ImportError:  # pragma: no cover
    bs4 = None  # type: ignore
    BeautifulSoup = None  # type: ignore

try:
    import webbrowser
except ImportError:  # pragma: no cover
    webbrowser = None  # type: ignore

try:
    import pyperclip
except ImportError:  # pragma: no cover
    pyperclip = None  # type: ignore

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.common.keys import Keys
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import (
        NoSuchElementException,
        TimeoutException,
        WebDriverException,
    )
except ImportError:  # pragma: no cover
    webdriver = None  # type: ignore
    By = Keys = WebDriverWait = EC = None  # type: ignore
    NoSuchElementException = TimeoutException = WebDriverException = Exception  # type: ignore

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("web_scraping")

# Default polite delay (seconds) between requests
DEFAULT_DELAY = 1.0
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (compatible; WebScrapingToolkit/1.0; +https://github.com/example)"
)

# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------
def _require(module, name: str):
    if module is None:
        raise ImportError(
            f"The '{name}' package is required. Install with:\n"
            f"    pip install --user {name}"
        )


def create_session(
    retries: int = 3,
    backoff: float = 0.5,
    status_forcelist: Sequence[int] = (429, 500, 502, 503, 504),
    user_agent: str = DEFAULT_USER_AGENT,
) -> "requests.Session":
    """Return a requests.Session with retry logic and a sensible User-Agent."""
    _require(requests, "requests")
    session = requests.Session()
    session.headers.update({"User-Agent": user_agent})
    retry = Retry(
        total=retries,
        backoff_factor=backoff,
        status_forcelist=status_forcelist,
        allowed_methods=["GET", "HEAD"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def polite_get(
    url: str,
    session: Optional["requests.Session"] = None,
    delay: float = DEFAULT_DELAY,
    timeout: int = 30,
    **kwargs,
) -> "requests.Response":
    """GET a URL with optional delay and automatic raise_for_status."""
    _require(requests, "requests")
    if session is None:
        session = create_session()
    if delay > 0:
        time.sleep(delay)
    log.info("GET %s", url)
    resp = session.get(url, timeout=timeout, **kwargs)
    resp.raise_for_status()
    return resp


def save_response(
    response: "requests.Response",
    filepath: Union[str, Path],
    chunk_size: int = 100_000,
) -> Path:
    """Write a Response object to disk in binary mode using iter_content."""
    path = Path(filepath)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as f:
        for chunk in response.iter_content(chunk_size):
            if chunk:  # filter keep-alive chunks
                f.write(chunk)
    log.info("Saved %s (%s bytes)", path, path.stat().st_size)
    return path


def download_url(
    url: str,
    dest: Union[str, Path],
    session: Optional["requests.Session"] = None,
    delay: float = DEFAULT_DELAY,
) -> Path:
    """Convenience: download a URL and save it to dest."""
    resp = polite_get(url, session=session, delay=delay)
    return save_response(resp, dest)


# ---------------------------------------------------------------------------
# 1. webbrowser helpers (mapIt style)
# ---------------------------------------------------------------------------
def open_map(address: Optional[str] = None, use_clipboard: bool = True) -> str:
    """
    Open Google Maps for the given address.
    If address is None and use_clipboard is True, read from clipboard
    (requires pyperclip). Returns the URL that was opened.
    """
    _require(webbrowser, "webbrowser (stdlib)")
    if address is None or address.strip() == "":
        if use_clipboard:
            _require(pyperclip, "pyperclip")
            address = pyperclip.paste().strip()
            if not address:
                raise ValueError("No address provided and clipboard is empty.")
        else:
            raise ValueError("No address provided.")
    # Google Maps place URL – works without extra tracking parameters
    url = "https://www.google.com/maps/place/" + requests.utils.quote(address)
    log.info("Opening map for: %s", address)
    webbrowser.open(url)
    return url


def open_urls(urls: Sequence[str], delay: float = 0.3) -> None:
    """Open each URL in a new browser tab (with a small delay)."""
    _require(webbrowser, "webbrowser (stdlib)")
    for u in urls:
        log.info("Opening %s", u)
        webbrowser.open(u)
        time.sleep(delay)


# ---------------------------------------------------------------------------
# 2 & 3. BeautifulSoup helpers
# ---------------------------------------------------------------------------
def get_soup(
    source: Union[str, Path, "requests.Response"],
    parser: str = "html.parser",
) -> "BeautifulSoup":
    """
    Create a BeautifulSoup object from a URL string, local file path,
    or an already-fetched Response object.
    """
    _require(bs4, "beautifulsoup4")
    if isinstance(source, (str, Path)) and Path(source).exists():
        html = Path(source).read_text(encoding="utf-8", errors="replace")
    elif isinstance(source, str) and source.startswith(("http://", "https://")):
        resp = polite_get(source)
        html = resp.text
    elif hasattr(source, "text"):  # Response-like
        html = source.text
    else:
        html = str(source)
    return BeautifulSoup(html, parser)


def select_text(soup: "BeautifulSoup", selector: str, default: str = "") -> str:
    """Return the stripped text of the first match, or default."""
    el = soup.select_one(selector)
    return el.get_text(strip=True) if el else default


def select_attr(
    soup: "BeautifulSoup", selector: str, attr: str, default: Optional[str] = None
) -> Optional[str]:
    """Return the value of *attr* from the first matching element."""
    el = soup.select_one(selector)
    if el is None:
        return default
    return el.get(attr, default)


def extract_links(
    soup: "BeautifulSoup",
    base_url: Optional[str] = None,
    selector: str = "a[href]",
) -> List[str]:
    """Return absolute URLs of all matching links."""
    links = []
    for a in soup.select(selector):
        href = a.get("href")
        if not href:
            continue
        if base_url:
            href = urljoin(base_url, href)
        links.append(href)
    return links


# ---------------------------------------------------------------------------
# 4. Search-results opener (generalised searchpypi)
# ---------------------------------------------------------------------------
class SearchResultsOpener:
    """
    Download a search-results page, extract result links with a CSS selector,
    and open the top-N results in the browser.
    """

    def __init__(
        self,
        search_url_template: str = "https://pypi.org/search/?q={query}",
        result_selector: str = "a.package-snippet",
        base_url: str = "https://pypi.org",
        max_results: int = 5,
        session: Optional["requests.Session"] = None,
    ):
        self.search_url_template = search_url_template
        self.result_selector = result_selector
        self.base_url = base_url.rstrip("/")
        self.max_results = max_results
        self.session = session or create_session()

    def search(self, query: str) -> List[str]:
        """Return the list of result URLs (does not open them)."""
        url = self.search_url_template.format(query=requests.utils.quote(query))
        resp = polite_get(url, session=self.session)
        soup = get_soup(resp)
        hrefs = []
        for el in soup.select(self.result_selector)[: self.max_results]:
            href = el.get("href")
            if href:
                hrefs.append(urljoin(self.base_url + "/", href))
        log.info("Found %d result(s) for %r", len(hrefs), query)
        return hrefs

    def open_results(self, query: str) -> List[str]:
        """Search and open the top results in the browser."""
        urls = self.search(query)
        open_urls(urls)
        return urls


# ---------------------------------------------------------------------------
# 5. XKCD-style sequential comic / image gallery downloader
# ---------------------------------------------------------------------------
def download_xkcd_comics(
    start_url: str = "https://xkcd.com",
    output_dir: Union[str, Path] = "xkcd",
    max_comics: Optional[int] = None,
    delay: float = 1.0,
    session: Optional["requests.Session"] = None,
) -> List[Path]:
    """
    Download XKCD comics starting from *start_url* and walking the
    “previous” link until the first comic or *max_comics* is reached.

    Returns list of saved file paths.
    """
    _require(requests, "requests")
    _require(bs4, "beautifulsoup4")
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    session = session or create_session()
    url = start_url
    saved: List[Path] = []
    count = 0

    while not url.endswith("#"):
        if max_comics is not None and count >= max_comics:
            break
        log.info("Downloading page %s", url)
        try:
            resp = polite_get(url, session=session, delay=delay)
        except Exception as exc:
            log.error("Failed to download page %s: %s", url, exc)
            break
        soup = get_soup(resp)

        # Comic image
        comic_img = soup.select_one("#comic img")
        if comic_img is None:
            log.warning("No comic image found on %s – skipping", url)
        else:
            src = comic_img.get("src", "")
            if src.startswith("//"):
                comic_url = "https:" + src
            elif src.startswith("/"):
                comic_url = "https://xkcd.com" + src
            else:
                comic_url = src
            try:
                img_resp = polite_get(comic_url, session=session, delay=0)
                filename = Path(urlparse(comic_url).path).name or f"comic_{count}.png"
                dest = out / filename
                save_response(img_resp, dest)
                saved.append(dest)
                count += 1
            except Exception as exc:
                log.error("Failed to download image %s: %s", comic_url, exc)

        # Previous link
        prev = soup.select_one('a[rel="prev"]')
        if prev is None:
            log.info("No previous link – stopping")
            break
        href = prev.get("href", "#")
        url = urljoin("https://xkcd.com", href)

    log.info("Downloaded %d comic(s) into %s", len(saved), out)
    return saved


# ---------------------------------------------------------------------------
# 6. Selenium browser wrapper
# ---------------------------------------------------------------------------
class SeleniumBrowser:
    """
    Thin convenience wrapper around selenium WebDriver.
    Supports Firefox (default) and Chrome.
    """

    def __init__(
        self,
        browser: str = "firefox",
        headless: bool = False,
        implicit_wait: float = 5.0,
    ):
        _require(webdriver, "selenium")
        self.browser_name = browser.lower()
        options = None
        if self.browser_name == "firefox":
            from selenium.webdriver.firefox.options import Options as FirefoxOptions
            options = FirefoxOptions()
            if headless:
                options.add_argument("-headless")
            self.driver = webdriver.Firefox(options=options)
        elif self.browser_name == "chrome":
            from selenium.webdriver.chrome.options import Options as ChromeOptions
            options = ChromeOptions()
            if headless:
                options.add_argument("--headless=new")
            self.driver = webdriver.Chrome(options=options)
        else:
            raise ValueError(f"Unsupported browser: {browser}")
        self.driver.implicitly_wait(implicit_wait)
        log.info("Started %s (headless=%s)", self.browser_name, headless)

    def get(self, url: str) -> None:
        log.info("Navigating to %s", url)
        self.driver.get(url)

    def find(self, by: str, value: str, many: bool = False):
        """
        by can be: id, name, class_name, tag_name, link_text,
                   partial_link_text, css_selector, xpath
        """
        locator_map = {
            "id": By.ID,
            "name": By.NAME,
            "class_name": By.CLASS_NAME,
            "tag_name": By.TAG_NAME,
            "link_text": By.LINK_TEXT,
            "partial_link_text": By.PARTIAL_LINK_TEXT,
            "css_selector": By.CSS_SELECTOR,
            "xpath": By.XPATH,
        }
        if by not in locator_map:
            raise ValueError(f"Unknown locator strategy: {by}")
        strategy = locator_map[by]
        if many:
            return self.driver.find_elements(strategy, value)
        return self.driver.find_element(strategy, value)

    def click(self, by: str, value: str) -> None:
        el = self.find(by, value)
        el.click()

    def type_text(self, by: str, value: str, text: str, clear: bool = True) -> None:
        el = self.find(by, value)
        if clear:
            el.clear()
        el.send_keys(text)

    def submit(self, by: str, value: str) -> None:
        el = self.find(by, value)
        el.submit()

    def send_keys_to_body(self, *keys) -> None:
        body = self.find("tag_name", "html")
        body.send_keys(*keys)

    def screenshot(self, path: Union[str, Path]) -> Path:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        self.driver.save_screenshot(str(path))
        log.info("Screenshot saved to %s", path)
        return path

    def quit(self) -> None:
        try:
            self.driver.quit()
        except Exception:
            pass
        log.info("Browser closed")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.quit()


# ---------------------------------------------------------------------------
# 7. Practice-project helpers
# ---------------------------------------------------------------------------
class LinkVerifier:
    """
    Given a starting URL, download the page, extract all links, and report
    which ones return a 404 (or other error status).
    """

    def __init__(
        self,
        session: Optional["requests.Session"] = None,
        delay: float = 0.5,
        timeout: int = 10,
    ):
        self.session = session or create_session()
        self.delay = delay
        self.timeout = timeout

    def verify(self, start_url: str) -> Dict[str, Any]:
        log.info("Verifying links on %s", start_url)
        try:
            resp = polite_get(start_url, session=self.session, delay=0)
        except Exception as exc:
            return {"start_url": start_url, "error": str(exc), "broken": [], "ok": []}
        soup = get_soup(resp)
        links = extract_links(soup, base_url=start_url)
        # Deduplicate while preserving order
        seen = set()
        unique_links = []
        for link in links:
            if link not in seen and link.startswith(("http://", "https://")):
                seen.add(link)
                unique_links.append(link)

        broken: List[Dict[str, Any]] = []
        ok: List[str] = []
        for link in unique_links:
            try:
                time.sleep(self.delay)
                r = self.session.head(link, timeout=self.timeout, allow_redirects=True)
                # Some servers reject HEAD – fall back to GET
                if r.status_code >= 400:
                    r = self.session.get(link, timeout=self.timeout, stream=True)
                if r.status_code >= 400:
                    broken.append({"url": link, "status": r.status_code})
                    log.warning("Broken (%s): %s", r.status_code, link)
                else:
                    ok.append(link)
            except Exception as exc:
                broken.append({"url": link, "status": "error", "detail": str(exc)})
                log.warning("Error checking %s: %s", link, exc)
        return {
            "start_url": start_url,
            "total_links": len(unique_links),
            "ok_count": len(ok),
            "broken_count": len(broken),
            "broken": broken,
            "ok": ok,
        }


def autoplay_2048(
    moves: int = 100,
    browser: str = "firefox",
    headless: bool = False,
) -> None:
    """
    Simple 2048 autoplayer that repeatedly sends the classic
    up-right-down-left pattern.
    """
    _require(webdriver, "selenium")
    game_url = "https://gabrielecirulli.github.io/2048/"
    with SeleniumBrowser(browser=browser, headless=headless) as bot:
        bot.get(game_url)
        time.sleep(1.5)  # let the board render
        pattern = [Keys.UP, Keys.RIGHT, Keys.DOWN, Keys.LEFT]
        for i in range(moves):
            key = pattern[i % 4]
            bot.send_keys_to_body(key)
            time.sleep(0.15)
        log.info("Finished %d moves", moves)
        # Keep the window open a moment so the user can see the score
        time.sleep(3)


# ---------------------------------------------------------------------------
# Demo / self-test helpers (used by the runner and notebook)
# ---------------------------------------------------------------------------
def demo_local_soup(example_path: Union[str, Path] = "data/example.html") -> None:
    """Parse the bundled example.html and print a few facts."""
    soup = get_soup(example_path)
    print("Title:", soup.title.string if soup.title else "(none)")
    print("Author:", select_text(soup, "#author"))
    print("Slogan:", select_text(soup, "p.slogan"))
    print("All <p> texts:")
    for p in soup.select("p"):
        print("  -", p.get_text(strip=True))


def demo_requests_text(
    url: str = "https://automatetheboringstuff.com/files/rj.txt",
    max_chars: int = 300,
) -> str:
    """Download a small text file and return a preview."""
    resp = polite_get(url, delay=0)
    text = resp.text
    log.info("Downloaded %d characters from %s", len(text), url)
    return text[:max_chars]


# ---------------------------------------------------------------------------
# CLI entry point (also imported by run_web_scraping.py)
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Web Scraping Toolkit – extended Automate-the-Boring-Stuff Ch.12",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = p.add_subparsers(dest="command", required=True)

    # map
    m = sub.add_parser("map", help="Open Google Maps for an address")
    m.add_argument("address", nargs="*", help="Street address (or omit to use clipboard)")
    m.add_argument("--no-clipboard", action="store_true")

    # search
    s = sub.add_parser("search", help="Open top PyPI (or custom) search results")
    s.add_argument("query", nargs="+", help="Search terms")
    s.add_argument("--max", type=int, default=5, help="Max tabs to open")
    s.add_argument("--selector", default="a.package-snippet")
    s.add_argument(
        "--template",
        default="https://pypi.org/search/?q={query}",
        help="Search URL template containing {query}",
    )

    # xkcd
    x = sub.add_parser("xkcd", help="Download XKCD comics")
    x.add_argument("--max", type=int, default=5, help="Max comics to download")
    x.add_argument("--outdir", default="xkcd", help="Output directory")
    x.add_argument("--start", default="https://xkcd.com")

    # verify
    v = sub.add_parser("verify", help="Check all links on a page for 404s")
    v.add_argument("url", help="Starting page URL")
    v.add_argument("--delay", type=float, default=0.5)

    # 2048
    g = sub.add_parser("2048", help="Autoplay 2048 (requires selenium + geckodriver)")
    g.add_argument("--moves", type=int, default=50)
    g.add_argument("--browser", choices=["firefox", "chrome"], default="firefox")
    g.add_argument("--headless", action="store_true")

    # local demo
    sub.add_parser("demo", help="Run offline BeautifulSoup demo on example.html")

    return p


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "map":
        addr = " ".join(args.address) if args.address else None
        open_map(addr, use_clipboard=not args.no_clipboard)
    elif args.command == "search":
        query = " ".join(args.query)
        opener = SearchResultsOpener(
            search_url_template=args.template,
            result_selector=args.selector,
            max_results=args.max,
        )
        opener.open_results(query)
    elif args.command == "xkcd":
        download_xkcd_comics(
            start_url=args.start,
            output_dir=args.outdir,
            max_comics=args.max,
        )
    elif args.command == "verify":
        verifier = LinkVerifier(delay=args.delay)
        result = verifier.verify(args.url)
        print(f"\nChecked {result['total_links']} links on {result['start_url']}")
        print(f"  OK     : {result['ok_count']}")
        print(f"  Broken : {result['broken_count']}")
        for b in result["broken"]:
            print(f"    [{b.get('status')}] {b['url']}")
    elif args.command == "2048":
        autoplay_2048(moves=args.moves, browser=args.browser, headless=args.headless)
    elif args.command == "demo":
        demo_local_soup()
    else:
        parser.print_help()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
