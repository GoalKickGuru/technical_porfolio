#!/usr/bin/env python3
"""
Reusable Web Scraping Template
===============================
Copy this file and adapt the configuration section for your own scraping task.
It demonstrates the core helpers from the Web Scraping Toolkit
(Chapter 12 of Automate the Boring Stuff – extended).
"""

from __future__ import annotations

import sys
from pathlib import Path

# Make the toolkit importable when this template lives in templates/
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from web_scraping import (
    open_map,
    download_url,
    get_soup,
    select_text,
    extract_links,
    SearchResultsOpener,
    download_xkcd_comics,
    LinkVerifier,
    SeleniumBrowser,
    create_session,
    polite_get,
    save_response,
)

# ---------------------------------------------------------------------------
# CONFIG – change these for your project
# ---------------------------------------------------------------------------
# Example 1 – open a map
ADDRESS = "870 Valencia St, San Francisco, CA 94110"

# Example 2 – download a single file
DOWNLOAD_URL = "https://automatetheboringstuff.com/files/rj.txt"
DOWNLOAD_DEST = "output/romeo_and_juliet.txt"

# Example 3 – parse a local HTML file or a live page
HTML_SOURCE = "data/example.html"          # or a full URL
CSS_SELECTOR = "#author"

# Example 4 – open search results
SEARCH_QUERY = "requests"
SEARCH_MAX = 3

# Example 5 – sequential image download (XKCD pattern)
COMIC_START = "https://xkcd.com"
COMIC_OUTDIR = "output/xkcd"
COMIC_MAX = 5

# Example 6 – link verification
VERIFY_URL = "https://nostarch.com"

# ---------------------------------------------------------------------------
# Minimal usage examples – uncomment the block you need
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    out = Path("output")
    out.mkdir(exist_ok=True)

    # --- 1. Open Google Maps ------------------------------------------------
    # open_map(ADDRESS)

    # --- 2. Download a file -------------------------------------------------
    # download_url(DOWNLOAD_URL, DOWNLOAD_DEST)

    # --- 3. Parse HTML with BeautifulSoup -----------------------------------
    soup = get_soup(HTML_SOURCE)
    print("Title :", soup.title.string if soup.title else None)
    print("Author:", select_text(soup, CSS_SELECTOR))
    print("Links :", extract_links(soup)[:5])

    # --- 4. Open top search results -----------------------------------------
    # opener = SearchResultsOpener(max_results=SEARCH_MAX)
    # opener.open_results(SEARCH_QUERY)

    # --- 5. Download a few XKCD comics --------------------------------------
    # download_xkcd_comics(COMIC_START, COMIC_OUTDIR, max_comics=COMIC_MAX)

    # --- 6. Verify links on a page ------------------------------------------
    # result = LinkVerifier().verify(VERIFY_URL)
    # print(f"Broken links: {result['broken_count']}")

    # --- 7. Selenium quick-start (requires geckodriver / chromedriver) ------
    # with SeleniumBrowser(browser="firefox", headless=True) as bot:
    #     bot.get("https://inventwithpython.com")
    #     bot.screenshot("output/inventwithpython.png")
    #     print("Page title:", bot.driver.title)

    print("\nTemplate finished – uncomment the sections you need.")
