#!/usr/bin/env python3
"""
Runner script for the Visualization in Python toolkit (Denis 2021, Ch.3).

Executes the full chapter demo, writes a short text summary, and ensures
all figures are generated under reports/figures/python_visualization/.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from python_visualization import (
    FIG_DIR,
    load_population,
    load_iris,
    percentage_vs_absolute,
    run_chapter3_demo,
    correlation_heatmap,
)


def main() -> None:
    print("=" * 70)
    print("  Visualization in Python – Full Demo (Denis Ch.3)")
    print("=" * 70)

    # 1. Core chapter walk-through
    results = run_chapter3_demo(save_figures=True, verbose=True)

    # 2. Extra summary
    pop = results["population"]
    pct_abs = percentage_vs_absolute(pop)
    iris = results["iris"]

    print("\n" + "-" * 70)
    print("Quick numeric checks")
    print("-" * 70)
    print(f"Population rows: {len(pop)}")
    print(f"Iris shape: {iris.shape}")
    print("\nHighest % change states:")
    print(pct_abs.head(5)[["NAME", "PPOPCHG_2019", "NPOPCHG_2019"]].to_string(index=False))

    # 3. Write a brief text log
    log_path = ROOT / "reports" / "python_visualization_run_log.txt"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "w") as f:
        f.write("Visualization in Python Toolkit – Run Log\n")
        f.write("=" * 50 + "\n")
        f.write(f"Population n = {len(pop)}\n")
        f.write(f"Iris n = {len(iris)}\n")
        f.write(f"Figures directory: {FIG_DIR}\n")
        f.write("\nTop percentage changes:\n")
        f.write(pct_abs.head(8).to_string(index=False))
        f.write("\n")
    print(f"\nRun log written to: {log_path}")
    print("\nDemo complete.")


if __name__ == "__main__":
    main()
