"""
Visualization in Python
=======================
Reusable module implementing and extending material from
Daniel J. Denis, "Applied Univariate, Bivariate, and Multivariate
Statistics Using Python" (Wiley, 2021), Chapter 3.

Core topics covered
-------------------
- Philosophy of visualization: perception becomes reality; simplicity over complexity
- Why percentage changes can mislead (absolute vs relative change)
- Scatterplots (matplotlib) and 2-D density / hexbin
- Correlograms / pairplots (seaborn) with hue and univariate diagonals
- Histograms vs bar graphs (continuity vs categorical)
- Side-by-side / overlaid density histograms
- Bubble plots (size encodes a third variable)
- Pie charts and their perceptual limitations
- Heatmaps (magnitude / density)
- Joint plots (scatter + hex + KDE)
- Line charts for trends over time / ordered sequences

Enhancements beyond the chapter
-------------------------------
- Publication-ready styling (seaborn theme, consistent colour palettes)
- Automatic figure saving with transparent backgrounds
- Explicit comparison of percentage vs absolute change on the same axes
- Annotated scatterplots and bar charts
- Faceted histograms by group
- Correlation matrix heatmap with hierarchical clustering option
- Interactive-friendly defaults (large markers, clear labels)
- Convenience runner that produces a full gallery of chapter figures

Dependencies: numpy, pandas, matplotlib, seaborn, scipy
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple, Union

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.figure import Figure

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "reports" / "figures" / "python_visualization"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# Sensible defaults
sns.set_theme(style="whitegrid", context="notebook", palette="muted")
plt.rcParams.update({
    "figure.dpi": 120,
    "savefig.dpi": 150,
    "savefig.bbox": "tight",
    "axes.titlesize": 13,
    "axes.labelsize": 11,
})

ArrayLike = Union[pd.Series, np.ndarray, List[float], List[int]]


# ===========================================================================
# 1. Data loading helpers
# ===========================================================================

def load_population(path: Optional[Path] = None) -> pd.DataFrame:
    """
    Load the synthetic US state / region population change data
    (mirrors the census-style table used in Ch.3).
    """
    path = path or DATA_DIR / "population_synth.csv"
    return pd.read_csv(path)


def load_iris() -> pd.DataFrame:
    """Classic iris dataset via seaborn (no local file needed)."""
    return sns.load_dataset("iris")


def make_fictitious_scatter() -> Tuple[List[float], List[float]]:
    """Return the small fictitious x/y vectors shown in the chapter."""
    x = [10, 15, 16, 23, 27, 38, 43, 56, 57, 60]
    y = [5, 8, 9, 13, 16, 20, 40, 45, 67, 75]
    return x, y


def make_random_bubble_data(n: int = 40, seed: int = 42) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Random x, y, z suitable for a bubble plot."""
    rng = np.random.default_rng(seed)
    x = rng.random(n)
    y = rng.random(n)
    z = rng.random(n)
    return x, y, z


def make_line_series(n: int = 1000, seed: int = 0) -> np.ndarray:
    """Cumulative sum of random normals – classic random-walk style series."""
    rng = np.random.default_rng(seed)
    return np.cumsum(rng.standard_normal(n))


# ===========================================================================
# 2. Percentage vs absolute change (core didactic example)
# ===========================================================================

def percentage_vs_absolute(
    df: Optional[pd.DataFrame] = None,
    pct_col: str = "PPOPCHG_2019",
    abs_col: str = "NPOPCHG_2019",
    name_col: str = "NAME",
    exclude_regions: bool = True,
) -> pd.DataFrame:
    """
    Return a tidy frame highlighting how large percentage changes
    can accompany tiny absolute changes (and vice-versa).
    """
    if df is None:
        df = load_population()
    work = df.copy()
    if exclude_regions:
        # keep only state-level rows (SUMLEV == 40) when available
        if "SUMLEV" in work.columns:
            work = work[work["SUMLEV"] == 40]
    work = work[[name_col, pct_col, abs_col]].dropna()
    work = work.sort_values(pct_col, ascending=False)
    return work.reset_index(drop=True)


def plot_pct_vs_abs(
    df: Optional[pd.DataFrame] = None,
    save: bool = True,
    fname: str = "pct_vs_abs_scatter.png",
) -> Figure:
    """
    Scatter of absolute population change vs percentage change.
    Demonstrates the lack of a simple linear relationship.
    """
    if df is None:
        df = load_population()
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.scatter(df["NPOPCHG_2019"], df["PPOPCHG_2019"], alpha=0.7, s=50, edgecolor="k", linewidth=0.4)
    ax.axhline(0, color="gray", lw=0.8, ls="--")
    ax.axvline(0, color="gray", lw=0.8, ls="--")
    ax.set_xlabel("Absolute change (NPOPCHG_2019)")
    ax.set_ylabel("Percentage change (PPOPCHG_2019)")
    ax.set_title("Percentage change vs absolute change\n(large % does not imply large absolute numbers)")
    # annotate a few extremes
    for _, row in df.nlargest(3, "PPOPCHG_2019").iterrows():
        ax.annotate(row["NAME"], (row["NPOPCHG_2019"], row["PPOPCHG_2019"]),
                    textcoords="offset points", xytext=(5, 5), fontsize=8)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 3. Scatterplots
# ===========================================================================

def simple_scatter(
    x: ArrayLike,
    y: ArrayLike,
    title: str = "Scatterplot",
    xlabel: str = "x",
    ylabel: str = "y",
    color: str = "C0",
    save: bool = True,
    fname: str = "simple_scatter.png",
) -> Figure:
    """Basic scatterplot using matplotlib."""
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.scatter(x, y, c=color, s=60, edgecolor="k", linewidth=0.5, alpha=0.85)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


def hist2d_scatter(
    x: ArrayLike,
    y: ArrayLike,
    bins: Tuple[int, int] = (50, 50),
    cmap: str = "Reds",
    title: str = "2-D Histogram / Density",
    save: bool = True,
    fname: str = "hist2d.png",
) -> Figure:
    """
    2-D histogram (as shown in the chapter with plt.hist2d).
    Useful when points heavily overlap.
    """
    fig, ax = plt.subplots(figsize=(6, 5))
    h = ax.hist2d(x, y, bins=bins, cmap=cmap)
    fig.colorbar(h[3], ax=ax, label="count")
    ax.set_title(title)
    ax.set_xlabel("x")
    ax.set_ylabel("y")
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 4. Correlograms / pairplots
# ===========================================================================

def iris_pairplot(
    hue: str = "species",
    kind: str = "scatter",
    markers: Optional[List[str]] = None,
    palette: str = "Set2",
    save: bool = True,
    fname: str = "iris_pairplot.png",
) -> sns.axisgrid.PairGrid:
    """
    Classic seaborn pairplot / correlogram on the iris data.
    Univariate distributions appear on the diagonal.
    """
    df = load_iris()
    markers = markers or ["o", "s", "D"]
    g = sns.pairplot(
        df,
        kind=kind,
        hue=hue,
        markers=markers,
        palette=palette,
        plot_kws=dict(s=40, edgecolor="white", linewidth=0.5, alpha=0.8),
        diag_kws=dict(fill=True, alpha=0.6),
    )
    g.fig.suptitle("Iris correlogram (pairplot)", y=1.02, fontsize=14)
    if save:
        g.savefig(FIG_DIR / fname)
    return g


def correlation_heatmap(
    df: Optional[pd.DataFrame] = None,
    method: str = "pearson",
    annot: bool = True,
    cmap: str = "coolwarm",
    save: bool = True,
    fname: str = "correlation_heatmap.png",
) -> Figure:
    """Correlation matrix rendered as a heatmap (numeric columns only)."""
    if df is None:
        df = load_iris().select_dtypes("number")
    else:
        df = df.select_dtypes("number")
    corr = df.corr(method=method)
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(
        corr,
        annot=annot,
        fmt=".2f",
        cmap=cmap,
        center=0,
        square=True,
        linewidths=0.5,
        cbar_kws={"shrink": 0.8},
        ax=ax,
    )
    ax.set_title(f"{method.title()} correlation heatmap")
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 5. Histograms and bar graphs
# ===========================================================================

def bar_chart(
    heights: Sequence[float],
    labels: Sequence[str],
    title: str = "Bar graph",
    color: Tuple[float, float, float, float] = (0.2, 0.4, 0.4, 0.6),
    save: bool = True,
    fname: str = "bar_chart.png",
) -> Figure:
    """Simple categorical bar chart (spaces between bars imply discreteness)."""
    fig, ax = plt.subplots(figsize=(7, 4.5))
    y_pos = np.arange(len(labels))
    ax.bar(y_pos, heights, color=color, edgecolor="k", linewidth=0.5)
    ax.set_xticks(y_pos)
    ax.set_xticklabels(labels)
    ax.set_ylabel("Height / Frequency")
    ax.set_title(title)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


def histogram(
    data: ArrayLike,
    bins: int = 20,
    color: str = "skyblue",
    title: str = "Histogram",
    xlabel: str = "Value",
    density: bool = False,
    save: bool = True,
    fname: str = "histogram.png",
) -> Figure:
    """Univariate histogram (bars touch → continuous variable)."""
    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.hist(data, bins=bins, color=color, edgecolor="k", linewidth=0.4, density=density, alpha=0.85)
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel("Density" if density else "Count")
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


def side_by_side_hist(
    series_a: ArrayLike,
    series_b: ArrayLike,
    label_a: str = "A",
    label_b: str = "B",
    color_a: str = "skyblue",
    color_b: str = "salmon",
    title: str = "Overlaid histograms",
    save: bool = True,
    fname: str = "side_by_side_hist.png",
) -> Figure:
    """
    Overlaid density histograms (as in the chapter's seaborn distplot example).
    Uses histplot for modern seaborn compatibility.
    """
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(series_a, color=color_a, label=label_a, kde=True, stat="density",
                 alpha=0.45, edgecolor="k", linewidth=0.3, ax=ax)
    sns.histplot(series_b, color=color_b, label=label_b, kde=True, stat="density",
                 alpha=0.45, edgecolor="k", linewidth=0.3, ax=ax)
    ax.legend()
    ax.set_title(title)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 6. Bubble plots
# ===========================================================================

def bubble_plot(
    x: ArrayLike,
    y: ArrayLike,
    size: ArrayLike,
    size_scale: float = 1000,
    alpha: float = 0.5,
    title: str = "Bubble plot",
    xlabel: str = "x",
    ylabel: str = "y",
    save: bool = True,
    fname: str = "bubble_plot.png",
) -> Figure:
    """
    Scatter where marker area encodes a third variable.
    Warns (via title) that relative sizes can be hard to judge.
    """
    fig, ax = plt.subplots(figsize=(7, 5.5))
    ax.scatter(x, y, s=np.asarray(size) * size_scale, alpha=alpha, edgecolor="k", linewidth=0.4)
    ax.set_title(title + "\n(size encodes a third variable – interpret with care)")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 7. Pie charts (and why they are often poor)
# ===========================================================================

def pie_chart(
    values: Sequence[float],
    labels: Sequence[str],
    title: str = "Pie chart (perceptual limitations)",
    explode: Optional[Sequence[float]] = None,
    save: bool = True,
    fname: str = "pie_chart.png",
) -> Figure:
    """
    Classic pie chart. The chapter emphasises that similar slice sizes
    are almost impossible to rank accurately by eye.
    """
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.pie(
        values,
        labels=labels,
        autopct="%1.1f%%",
        startangle=90,
        explode=explode,
        wedgeprops=dict(edgecolor="w", linewidth=1),
    )
    ax.set_title(title)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


def bar_vs_pie_comparison(
    values: Sequence[float] = (8, 8, 1, 2),
    labels: Sequence[str] = ("a", "b", "c", "d"),
    save: bool = True,
    fname: str = "bar_vs_pie.png",
) -> Figure:
    """
    Side-by-side demonstration that a bar chart makes rank order obvious
    while a pie chart does not.
    """
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))
    # pie
    axes[0].pie(values, labels=labels, autopct="%1.0f%%", startangle=90)
    axes[0].set_title("Pie – hard to rank a vs b")
    # bar
    axes[1].bar(labels, values, color=["C0", "C1", "C2", "C3"], edgecolor="k")
    axes[1].set_title("Bar – rank order immediately clear")
    axes[1].set_ylabel("Value")
    fig.suptitle("Why bar graphs usually beat pie charts", y=1.02)
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 8. Heatmaps & joint plots
# ===========================================================================

def random_heatmap(
    n: int = 5,
    seed: int = 1,
    save: bool = True,
    fname: str = "random_heatmap.png",
) -> Figure:
    """Heatmap of a random numeric matrix (chapter-style example)."""
    rng = np.random.default_rng(seed)
    df = pd.DataFrame(rng.random((n, n)), columns=list("abcde")[:n])
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(df, annot=True, fmt=".2f", cmap="YlOrRd", ax=ax)
    ax.set_title("Heatmap of random matrix")
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


def iris_jointplots(
    x: str = "sepal_length",
    y: str = "sepal_width",
    save: bool = True,
) -> List[sns.axisgrid.JointGrid]:
    """
    Three joint-plot variants (hex, scatter, kde) as demonstrated in the chapter.
    """
    df = load_iris()
    grids = []
    for kind, fname in [("hex", "joint_hex.png"), ("scatter", "joint_scatter.png"), ("kde", "joint_kde.png")]:
        g = sns.jointplot(data=df, x=x, y=y, kind=kind, height=5)
        g.fig.suptitle(f"Joint plot – kind='{kind}'", y=1.02)
        if save:
            g.savefig(FIG_DIR / fname)
        grids.append(g)
    return grids


# ===========================================================================
# 9. Line charts
# ===========================================================================

def line_chart(
    values: ArrayLike,
    title: str = "Line chart (random walk)",
    xlabel: str = "Index",
    ylabel: str = "Value",
    save: bool = True,
    fname: str = "line_chart.png",
) -> Figure:
    """Simple line plot – ideal for ordered / time-series data."""
    fig, ax = plt.subplots(figsize=(9, 4))
    ax.plot(values, lw=1.2, color="C0")
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.axhline(0, color="gray", lw=0.6, ls="--")
    if save:
        fig.savefig(FIG_DIR / fname)
    return fig


# ===========================================================================
# 10. Convenience gallery runner
# ===========================================================================

def run_chapter3_demo(save_figures: bool = True, verbose: bool = True) -> Dict[str, Any]:
    """
    Execute a complete walk-through of the visualisation techniques
    presented in Chapter 3 (plus a few practical enhancements).
    Returns a dictionary of key objects for further inspection.
    """
    results: Dict[str, Any] = {}

    if verbose:
        print("=" * 70)
        print("  Visualization in Python – Chapter 3 Demo (Denis 2021)")
        print("=" * 70)

    # --- population percentage vs absolute ---
    pop = load_population()
    results["population"] = pop
    pct_abs = percentage_vs_absolute(pop)
    results["pct_vs_abs_table"] = pct_abs
    if verbose:
        print("\nTop-5 states by percentage population change:")
        print(pct_abs.head().to_string(index=False))
    plot_pct_vs_abs(pop, save=save_figures)

    # --- fictitious scatter ---
    x, y = make_fictitious_scatter()
    results["fictitious_xy"] = (x, y)
    simple_scatter(x, y, title="Fictitious scatter (chapter data)", save=save_figures)
    hist2d_scatter(x, y, bins=(30, 30), save=save_figures)

    # --- iris pairplot & correlation heatmap ---
    iris = load_iris()
    results["iris"] = iris
    iris_pairplot(save=save_figures)
    correlation_heatmap(iris, save=save_figures)

    # --- bar & histogram ---
    bar_chart([10, 20, 30, 75, 100], list("ABCDE"), title="Example bar graph", save=save_figures)
    histogram(iris["sepal_length"], bins=15, title="Iris sepal length histogram",
              xlabel="Sepal length (cm)", save=save_figures)
    side_by_side_hist(
        iris["sepal_length"], iris["sepal_width"],
        label_a="Sepal length", label_b="Sepal width",
        title="Overlaid densities – iris sepal dimensions",
        save=save_figures,
    )

    # --- bubble ---
    bx, by, bz = make_random_bubble_data()
    bubble_plot(bx, by, bz, size_scale=800, title="Random bubble plot", save=save_figures)

    # --- pie & comparison ---
    pie_chart([8, 8, 1, 2], list("abcd"), save=save_figures)
    bar_vs_pie_comparison(save=save_figures)

    # --- heatmap & joint ---
    random_heatmap(save=save_figures)
    iris_jointplots(save=save_figures)

    # --- line ---
    series = make_line_series()
    results["line_series"] = series
    line_chart(series, title="Cumulative random walk (line chart)", save=save_figures)

    if verbose:
        print(f"\nFigures written to: {FIG_DIR}")
        print("Demo complete.")

    return results


if __name__ == "__main__":
    run_chapter3_demo(save_figures=True, verbose=True)
