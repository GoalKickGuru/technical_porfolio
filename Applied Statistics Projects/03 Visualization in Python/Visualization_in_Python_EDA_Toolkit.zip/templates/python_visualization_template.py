"""
Reusable Template – Visualization in Python
===========================================
Copy this file and adapt the configuration block for any new dataset.

Implements the core techniques from Denis (2021) Chapter 3 plus practical
extensions useful for everyday exploratory data analysis.
"""

from pathlib import Path
import sys

# Make the project scripts importable when the template is run from anywhere
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from python_visualization import (
    load_population,
    load_iris,
    percentage_vs_absolute,
    plot_pct_vs_abs,
    simple_scatter,
    hist2d_scatter,
    iris_pairplot,
    correlation_heatmap,
    bar_chart,
    histogram,
    side_by_side_hist,
    bubble_plot,
    pie_chart,
    bar_vs_pie_comparison,
    random_heatmap,
    iris_jointplots,
    line_chart,
    make_fictitious_scatter,
    make_random_bubble_data,
    make_line_series,
    FIG_DIR,
)

# ---------------------------------------------------------------------------
# 1. Configure
# ---------------------------------------------------------------------------
DATA_PATH = ROOT / "data" / "population_synth.csv"   # change me
OUTPUT_DIR = FIG_DIR
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# 2. Load & inspect
# ---------------------------------------------------------------------------
pop = load_population(DATA_PATH)
print("Population head:")
print(pop.head())
print("Shape:", pop.shape)

iris = load_iris()
print("\nIris head:")
print(iris.head())

# ---------------------------------------------------------------------------
# 3. Core didactic plot – percentage vs absolute change
# ---------------------------------------------------------------------------
pct_abs = percentage_vs_absolute(pop)
print("\nTop percentage changes:")
print(pct_abs.head(8))
plot_pct_vs_abs(pop, save=True, fname="template_pct_vs_abs.png")

# ---------------------------------------------------------------------------
# 4. Scatter & density
# ---------------------------------------------------------------------------
x, y = make_fictitious_scatter()
simple_scatter(x, y, title="Template scatter", save=True, fname="template_scatter.png")
hist2d_scatter(x, y, bins=(40, 40), save=True, fname="template_hist2d.png")

# ---------------------------------------------------------------------------
# 5. Correlogram & correlation heatmap
# ---------------------------------------------------------------------------
iris_pairplot(save=True, fname="template_pairplot.png")
correlation_heatmap(iris, save=True, fname="template_corr_heatmap.png")

# ---------------------------------------------------------------------------
# 6. Histograms / bars
# ---------------------------------------------------------------------------
bar_chart([12, 25, 40, 55, 80], list("VWXYZ"), title="Template bar chart",
          save=True, fname="template_bar.png")
histogram(iris["petal_length"], bins=18, title="Petal length histogram",
          xlabel="Petal length (cm)", save=True, fname="template_hist.png")
side_by_side_hist(
    iris["petal_length"], iris["petal_width"],
    label_a="Petal length", label_b="Petal width",
    save=True, fname="template_overlay_hist.png",
)

# ---------------------------------------------------------------------------
# 7. Bubble, pie, heatmap, joint, line
# ---------------------------------------------------------------------------
bx, by, bz = make_random_bubble_data(n=50)
bubble_plot(bx, by, bz, size_scale=600, save=True, fname="template_bubble.png")
pie_chart([15, 25, 30, 10, 20], list("ABCDE"), save=True, fname="template_pie.png")
bar_vs_pie_comparison(save=True, fname="template_bar_vs_pie.png")
random_heatmap(n=6, save=True, fname="template_heatmap.png")
iris_jointplots(save=True)
line_chart(make_line_series(800), title="Template line chart",
           save=True, fname="template_line.png")

print(f"\nAll template figures saved under: {OUTPUT_DIR}")
print("Template run finished.")
