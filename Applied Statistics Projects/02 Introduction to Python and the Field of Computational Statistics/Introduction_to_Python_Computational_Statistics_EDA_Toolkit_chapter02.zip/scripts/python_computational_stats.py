"""
Introduction to Python and Computational Statistics
====================================================
Reusable module implementing and extending material from
Daniel J. Denis, "Applied Univariate, Bivariate, and Multivariate
Statistics Using Python" (Wiley, 2021), Chapter 2.

Core topics covered
-------------------
- Python package management and imports (numpy, pandas, scipy, matplotlib, seaborn, statistics, math)
- Building DataFrames from dictionaries and loading external CSV / seaborn datasets
- Manual and package-based z-score computation
- Basic descriptive statistics (mean, median, mode, variance, std, skew, kurtosis)
- Visualization of raw vs. standardized distributions
- Pseudo-random data generation
- Mathematical constants (e, π) and the normal density
- Essential linear & matrix algebra for statistics (vectors, matrices, identity,
  covariance / correlation matrices, eigenvalues / eigenvectors)

Enhancements beyond the chapter
-------------------------------
- Clean, typed functions with docstrings
- Robust handling of sample vs population standard deviation (ddof)
- Side-by-side histogram comparison (raw vs z)
- Full descriptive summary dictionary
- Matrix algebra helpers that produce publication-ready printed output
- Convenience runners that save figures to disk

Dependencies: numpy, pandas, scipy, matplotlib, seaborn, statistics, math
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import math
import statistics

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

# ---------------------------------------------------------------------------
# Paths & constants
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "reports" / "figures" / "python_intro"
FIG_DIR.mkdir(parents=True, exist_ok=True)

ArrayLike = Union[pd.Series, np.ndarray, List[float], List[int]]


# ===========================================================================
# 1. Data loading helpers
# ===========================================================================

def load_achievement(path: Optional[Path] = None) -> pd.DataFrame:
    """
    Load the fictitious mathematics achievement data used throughout Ch.2.

    Columns
    -------
    ac     : achievement score
    teach  : teacher id (1-4)
    text   : textbook id (1-2)
    """
    path = path or DATA_DIR / "achievement_scores.csv"
    df = pd.read_csv(path)
    return df


def load_iq_data(path: Optional[Path] = None) -> pd.DataFrame:
    """Load the synthetic IQ data (verbal, quant, analytic, group)."""
    path = path or DATA_DIR / "iq_data.csv"
    return pd.read_csv(path)


def load_iris() -> pd.DataFrame:
    """Load the classic iris dataset via seaborn (no local file needed)."""
    return sns.load_dataset("iris")


def build_dataframe_from_dict(data: Dict[str, List]) -> pd.DataFrame:
    """
    Build a pandas DataFrame from a plain Python dictionary of lists.
    Mirrors the chapter's first example.
    """
    return pd.DataFrame(data)


# ===========================================================================
# 2. Z-score computation
# ===========================================================================

def zscore_manual(data: ArrayLike, ddof: int = 1) -> np.ndarray:
    """
    Compute z-scores the long way shown in the chapter:

        z = (x - mean) / std

    Parameters
    ----------
    data : array-like
    ddof : int
        Delta degrees of freedom. 1 = sample std (default, matches chapter),
        0 = population std.
    """
    s = pd.Series(data).dropna()
    mean = s.mean()
    std = s.std(ddof=ddof)
    return ((s - mean) / std).to_numpy()


def zscore_scipy(data: ArrayLike, ddof: int = 1) -> np.ndarray:
    """Compute z-scores using scipy.stats.zscore (preferred production method)."""
    s = pd.Series(data).dropna()
    return stats.zscore(s, axis=0, ddof=ddof)


def compare_zscore_methods(data: ArrayLike) -> pd.DataFrame:
    """Return a side-by-side comparison of manual vs scipy z-scores."""
    manual = zscore_manual(data)
    scipy_ = zscore_scipy(data)
    return pd.DataFrame({"manual": manual, "scipy": scipy_, "diff": manual - scipy_})


# ===========================================================================
# 3. Descriptive statistics
# ===========================================================================

def descriptive_summary(data: ArrayLike, name: str = "variable") -> Dict[str, Any]:
    """
    Compute a rich set of descriptive statistics.

    Returns a dictionary containing:
    - n, mean, median, mode, variance, std (sample & population),
      min, max, range, skew, kurtosis, IQR, Q1, Q3
    """
    s = pd.Series(data).dropna()
    if s.empty:
        return {"name": name, "n": 0}

    # Mode may not be unique
    try:
        mode_val = statistics.mode(s)
        mode_note = "unique"
    except statistics.StatisticsError:
        mode_val = s.mode().tolist()
        mode_note = "multi-modal"

    return {
        "name": name,
        "n": int(s.count()),
        "mean": float(s.mean()),
        "median": float(s.median()),
        "mode": mode_val,
        "mode_note": mode_note,
        "variance_sample": float(s.var(ddof=1)),
        "variance_population": float(s.var(ddof=0)),
        "std_sample": float(s.std(ddof=1)),
        "std_population": float(s.std(ddof=0)),
        "min": float(s.min()),
        "max": float(s.max()),
        "range": float(s.max() - s.min()),
        "q1": float(s.quantile(0.25)),
        "q3": float(s.quantile(0.75)),
        "iqr": float(s.quantile(0.75) - s.quantile(0.25)),
        "skew": float(stats.skew(s)),
        "kurtosis": float(stats.kurtosis(s)),  # Fisher definition (normal = 0)
    }


def print_descriptive_summary(summary: Dict[str, Any]) -> None:
    """Pretty-print a descriptive_summary dictionary."""
    print(f"\n=== Descriptive Summary: {summary.get('name', 'variable')} ===")
    for k, v in summary.items():
        if k == "name":
            continue
        if isinstance(v, float):
            print(f"  {k:25s}: {v:10.4f}")
        else:
            print(f"  {k:25s}: {v}")


# ===========================================================================
# 4. Visualization helpers
# ===========================================================================

def plot_raw_vs_z(
    data: ArrayLike,
    title: str = "Raw scores vs. Z-scores",
    save_name: Optional[str] = "raw_vs_z.png",
) -> Path:
    """
    Side-by-side histograms of the original distribution and its z-score
    transformation. Demonstrates that linear standardization does not
    change shape.
    """
    s = pd.Series(data).dropna()
    z = zscore_scipy(s)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].hist(s, bins="auto", color="steelblue", edgecolor="white", alpha=0.85)
    axes[0].set_title("Original distribution")
    axes[0].set_xlabel("Value")
    axes[0].set_ylabel("Frequency")
    axes[0].axvline(s.mean(), color="red", linestyle="--", label=f"mean={s.mean():.2f}")
    axes[0].legend()

    axes[1].hist(z, bins="auto", color="darkorange", edgecolor="white", alpha=0.85)
    axes[1].set_title("Z-score distribution (mean≈0, sd≈1)")
    axes[1].set_xlabel("Z-score")
    axes[1].axvline(0, color="red", linestyle="--", label="mean=0")
    axes[1].legend()

    fig.suptitle(title, fontsize=13, fontweight="bold")
    fig.tight_layout()

    out = FIG_DIR / (save_name or "raw_vs_z.png")
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out


def plot_normal_density(
    mu: float = 0.0,
    sigma: float = 1.0,
    save_name: str = "normal_density.png",
) -> Path:
    """Plot the theoretical normal density using the formula from the chapter."""
    x = np.linspace(mu - 4 * sigma, mu + 4 * sigma, 400)
    # Chapter formula
    y = (1 / (np.sqrt(2 * np.pi * sigma**2))) * np.exp(-((x - mu) ** 2) / (2 * sigma**2))

    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(x, y, color="navy", lw=2, label=f"N(μ={mu}, σ²={sigma**2})")
    ax.fill_between(x, y, alpha=0.25, color="skyblue")
    ax.axvline(mu, color="red", ls="--", label="μ")
    ax.set_title("Normal density (chapter formula)")
    ax.set_xlabel("x")
    ax.set_ylabel("f(x)")
    ax.legend()
    fig.tight_layout()

    out = FIG_DIR / save_name
    fig.savefig(out, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return out


# ===========================================================================
# 5. Random data & mathematical constants
# ===========================================================================

def generate_standard_normal(n: int = 100, seed: Optional[int] = 42) -> np.ndarray:
    """Generate n pseudo-random draws from N(0,1)."""
    rng = np.random.default_rng(seed)
    return rng.standard_normal(n)


def math_constants() -> Dict[str, float]:
    """Return Euler's number and π (exact values from the math module)."""
    return {"e": math.e, "pi": math.pi}


def normal_pdf(x: float, mu: float = 0.0, sigma: float = 1.0) -> float:
    """
    Evaluate the normal density at a single point using the chapter formula.

        f(x) = 1 / sqrt(2 π σ²) * exp( -(x-μ)² / (2σ²) )
    """
    return (1 / math.sqrt(2 * math.pi * sigma**2)) * math.exp(
        -((x - mu) ** 2) / (2 * sigma**2)
    )


# ===========================================================================
# 6. Linear & matrix algebra helpers
# ===========================================================================

def create_vector(values: List[float]) -> np.ndarray:
    """Create a 1-D numpy vector (column-like by convention)."""
    return np.asarray(values, dtype=float)


def create_matrix(rows: List[List[float]]) -> np.ndarray:
    """Create a 2-D numpy matrix from a list of rows."""
    return np.asarray(rows, dtype=float)


def identity_matrix(n: int = 3) -> np.ndarray:
    """Return an n × n identity matrix (exercise 10 in the chapter)."""
    return np.eye(n)


def covariance_matrix(data: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the sample covariance matrix.
    Diagonal = variances; off-diagonal = covariances.
    Symmetric (upper triangle == lower triangle).
    """
    return data.cov()


def correlation_matrix(data: pd.DataFrame) -> pd.DataFrame:
    """
    Compute the Pearson correlation matrix (standardized counterpart
    of the covariance matrix).
    """
    return data.corr()


def eigenvalues_eigenvectors(A: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
    """
    Solve the classic eigen-equation Ax = λx.

    Returns
    -------
    eigenvalues : 1-D array of λ
    eigenvectors : 2-D array whose columns are the corresponding eigenvectors
    """
    eigvals, eigvecs = np.linalg.eig(A)
    return eigvals, eigvecs


def demonstrate_eigen(A: Optional[np.ndarray] = None) -> None:
    """Print a short demonstration of the eigen-decomposition."""
    if A is None:
        A = np.array([[2.0, 1.0], [1.0, 2.0]])
    print("Matrix A:")
    print(A)
    vals, vecs = eigenvalues_eigenvectors(A)
    print("\nEigenvalues (λ):", vals)
    print("Eigenvectors (columns):")
    print(vecs)
    # Verify Ax = λx for first eigenpair
    print("\nVerification for first eigenpair (Ax should equal λx):")
    print("Ax =", A @ vecs[:, 0])
    print("λx =", vals[0] * vecs[:, 0])


# ===========================================================================
# 7. High-level convenience runners
# ===========================================================================

def run_chapter2_demo(
    save_figures: bool = True,
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    Execute a complete walk-through of the chapter material and
    return a dictionary of key results + paths to saved figures.
    """
    results: Dict[str, Any] = {}

    # --- 1. Load achievement data ---
    df = load_achievement()
    results["achievement_df"] = df
    if verbose:
        print("Achievement data (first 6 rows):")
        print(df.head(6))
        print(f"Shape: {df.shape}")

    ac = df["ac"]

    # --- 2. Z-scores ---
    z_manual = zscore_manual(ac)
    z_scipy = zscore_scipy(ac)
    results["z_manual"] = z_manual
    results["z_scipy"] = z_scipy
    if verbose:
        print("\nFirst 5 z-scores (scipy):")
        print(z_scipy[:5])

    # --- 3. Descriptives ---
    summary = descriptive_summary(ac, name="achievement (ac)")
    results["descriptive_summary"] = summary
    if verbose:
        print_descriptive_summary(summary)

    # --- 4. Figures ---
    if save_figures:
        p1 = plot_raw_vs_z(ac, title="Mathematics Achievement – Raw vs Z")
        p2 = plot_normal_density()
        results["fig_raw_vs_z"] = str(p1)
        results["fig_normal"] = str(p2)
        if verbose:
            print(f"\nFigures saved:\n  {p1}\n  {p2}")

    # --- 5. Math constants & normal pdf ---
    constants = math_constants()
    results["constants"] = constants
    results["normal_pdf_at_0"] = normal_pdf(0.0)
    if verbose:
        print(f"\nMath constants: e = {constants['e']:.10f}, π = {constants['pi']:.10f}")
        print(f"Normal pdf at x=0 (standard): {results['normal_pdf_at_0']:.6f}")

    # --- 6. Random data ---
    rnd = generate_standard_normal(20)
    results["random_sample"] = rnd
    if verbose:
        print("\n20 pseudo-random N(0,1) draws:")
        print(np.round(rnd, 4))

    # --- 7. Linear algebra ---
    if verbose:
        print("\n--- Linear Algebra Demo ---")
        print("3×3 Identity matrix:")
        print(identity_matrix(3))

        # Covariance & correlation on a small numeric subset
        num = df[["ac"]].copy()
        # add a second numeric column for illustration
        num["ac_plus_noise"] = ac + np.random.default_rng(0).normal(0, 5, len(ac))
        print("\nCovariance matrix:")
        print(covariance_matrix(num).round(3))
        print("\nCorrelation matrix:")
        print(correlation_matrix(num).round(3))

        demonstrate_eigen()

    results["identity_3x3"] = identity_matrix(3)
    return results


if __name__ == "__main__":
    run_chapter2_demo(verbose=True)
