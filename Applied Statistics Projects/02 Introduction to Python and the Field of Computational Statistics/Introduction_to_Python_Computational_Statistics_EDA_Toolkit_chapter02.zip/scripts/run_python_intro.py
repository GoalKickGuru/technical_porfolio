#!/usr/bin/env python3
"""
Runner script for the Introduction to Python & Computational Statistics toolkit.

Executes the full Chapter-2 demo, writes a short text summary, and ensures
all figures are generated under reports/figures/python_intro/.
"""

from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from python_computational_stats import (
    FIG_DIR,
    load_achievement,
    load_iq_data,
    load_iris,
    run_chapter2_demo,
    descriptive_summary,
    print_descriptive_summary,
    zscore_scipy,
    plot_raw_vs_z,
    covariance_matrix,
    correlation_matrix,
    identity_matrix,
    demonstrate_eigen,
)


def main() -> None:
    print("=" * 70)
    print("  Introduction to Python & Computational Statistics – Full Demo")
    print("=" * 70)

    # 1. Core chapter walk-through
    results = run_chapter2_demo(save_figures=True, verbose=True)

    # 2. Extra data sets
    print("\n" + "-" * 70)
    print("Additional data sets")
    print("-" * 70)

    iq = load_iq_data()
    print("\nIQ data (head):")
    print(iq.head())
    print("\nDescriptives for verbal scores:")
    print_descriptive_summary(descriptive_summary(iq["verbal"], "verbal"))

    iris = load_iris()
    print("\nIris data (head):")
    print(iris.head())
    print(f"Iris shape: {iris.shape}")

    # 3. Quick matrix algebra on iris numeric columns
    numeric = iris.select_dtypes("number")
    print("\nIris correlation matrix:")
    print(correlation_matrix(numeric).round(3))

    # 4. Write a brief text log
    log_path = ROOT / "reports" / "python_intro_run_log.txt"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with open(log_path, "w") as f:
        f.write("Python Computational Statistics Toolkit – Run Log\n")
        f.write("=" * 50 + "\n")
        f.write(f"Achievement n = {len(results['achievement_df'])}\n")
        f.write(f"Mean ac = {results['descriptive_summary']['mean']:.4f}\n")
        f.write(f"Std (sample) = {results['descriptive_summary']['std_sample']:.4f}\n")
        f.write(f"Skew = {results['descriptive_summary']['skew']:.4f}\n")
        f.write(f"Kurtosis = {results['descriptive_summary']['kurtosis']:.4f}\n")
        f.write(f"Figures directory: {FIG_DIR}\n")
        f.write(f"Identity 3×3:\n{results['identity_3x3']}\n")
    print(f"\nRun log written to: {log_path}")
    print("\nDemo complete.")


if __name__ == "__main__":
    main()
