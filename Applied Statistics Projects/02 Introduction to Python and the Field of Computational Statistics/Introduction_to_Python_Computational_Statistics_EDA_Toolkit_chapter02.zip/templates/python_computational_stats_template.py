"""
Reusable Template – Introduction to Python & Computational Statistics
======================================================================
Copy this file and adapt the configuration block for any new numeric dataset.

Implements the core techniques from Denis (2021) Chapter 2 plus practical
extensions useful for everyday data analysis.
"""

from pathlib import Path
import sys

# Make the project scripts importable when the template is run from anywhere
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from python_computational_stats import (
    load_achievement,          # or load_iq_data / load_iris / your own loader
    descriptive_summary,
    print_descriptive_summary,
    zscore_manual,
    zscore_scipy,
    compare_zscore_methods,
    plot_raw_vs_z,
    plot_normal_density,
    generate_standard_normal,
    math_constants,
    normal_pdf,
    identity_matrix,
    covariance_matrix,
    correlation_matrix,
    demonstrate_eigen,
    FIG_DIR,
)

# ---------------------------------------------------------------------------
# 1. Configure
# ---------------------------------------------------------------------------
DATA_PATH = ROOT / "data" / "achievement_scores.csv"   # change me
NUMERIC_COL = "ac"                                     # change me
OUTPUT_DIR = FIG_DIR
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# 2. Load & inspect
# ---------------------------------------------------------------------------
df = load_achievement(DATA_PATH)   # replace with your loader if needed
print(df.head())
print(df.shape)
print(df.dtypes)

series = df[NUMERIC_COL]

# ---------------------------------------------------------------------------
# 3. Descriptive statistics
# ---------------------------------------------------------------------------
summary = descriptive_summary(series, name=NUMERIC_COL)
print_descriptive_summary(summary)

# ---------------------------------------------------------------------------
# 4. Z-scores (manual vs package)
# ---------------------------------------------------------------------------
print("\nZ-score comparison (first 5):")
print(compare_zscore_methods(series).head())

# ---------------------------------------------------------------------------
# 5. Visualizations
# ---------------------------------------------------------------------------
plot_raw_vs_z(series, title=f"{NUMERIC_COL} – Raw vs Z", save_name=f"{NUMERIC_COL}_raw_vs_z.png")
plot_normal_density(save_name="normal_density_demo.png")

# ---------------------------------------------------------------------------
# 6. Math constants & random data
# ---------------------------------------------------------------------------
print("\nConstants:", math_constants())
print("Normal pdf at 0:", normal_pdf(0.0))
print("Random N(0,1) sample:", generate_standard_normal(8))

# ---------------------------------------------------------------------------
# 7. Linear algebra quick checks
# ---------------------------------------------------------------------------
print("\nIdentity 3×3:")
print(identity_matrix(3))

# If you have ≥2 numeric columns you can compute cov / corr
# numeric = df.select_dtypes("number")
# print(covariance_matrix(numeric))
# print(correlation_matrix(numeric))

demonstrate_eigen()

print(f"\nFigures saved under: {OUTPUT_DIR}")
print("Template finished successfully.")
